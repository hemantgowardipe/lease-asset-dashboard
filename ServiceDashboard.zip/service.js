(function () {
  "use strict";

  var CATEGORY_REPOSITORY = "Workflow_Category";
  var CATEGORY_FIELDS = ["CategoryName", "Sequence", "RecordID"];
  var WORKFLOW_TEMPLATE = "ehelpdesk";
  var DEFAULT_APP_ICON = "/SmartHR/assets/img/default_service.png";
  var SETTING_PATH_PREFIX = "hp-setting";

  var workflowConfigPromise = null;
  var categoryRowsPromise = null;

  // Reference-data cache (localStorage, short TTL). Shared cache-key scheme
  // with service-dashboard.js so navigating between Service Catalog and
  // Service Dashboard reuses the same cached app list instead of refetching.
  // Only for slow-changing config lists - ticket/live data is never cached.
  var REF_CACHE_TTL_MS = 300000;
  var REF_CACHE_PREFIX = "qaf_refcache:";

  function readRefCache(key) {
    try {
      var raw = window.localStorage && window.localStorage.getItem(REF_CACHE_PREFIX + key);
      if (!raw) return null;
      var entry = JSON.parse(raw);
      if (!entry || typeof entry !== "object" || typeof entry.t !== "number") return null;
      if (Date.now() - entry.t > REF_CACHE_TTL_MS) return null;
      return entry.d;
    } catch (_) {
      return null;
    }
  }

  function writeRefCache(key, data) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(
          REF_CACHE_PREFIX + key,
          JSON.stringify({ t: Date.now(), d: data })
        );
      }
    } catch (_) {}
  }

  function invalidateRefCache(key) {
    try {
      if (window.localStorage) {
        window.localStorage.removeItem(REF_CACHE_PREFIX + key);
      }
    } catch (_) {}
  }

  var state = {
    categories: [],
    apps: [],
    filteredApps: null,
    searchQuery: "",
  };

  var CURRENT_PAGE_PATH = "/pages/ServiceCatalog";

  var HELPDESK_PAGE_PATHS = [
    "/pages/ServiceDashboard",
    "/pages/ServiceCatalog",
    "/pages/KnowledgeBase",
    "/pages/TeamDashboard",
    "/pages/ReportAndAnalytics",
    "/pages/HelpdeskPermission",
    "/pages/HelpdeskStatus",
    "/pages/HelpdeskPriority",
  ];

  var HELPDESK_PERMISSION_PAGES = {
    "46-3": [
      "/pages/ServiceDashboard",
      "/pages/ServiceCatalog",
      "/pages/KnowledgeBase",
      "/pages/TeamDashboard",
      "/pages/ReportAndAnalytics",
      "/pages/HelpdeskPermission",
      "/pages/HelpdeskStatus",
      "/pages/HelpdeskPriority",
    ],
    "46-2": [
      "/pages/ServiceDashboard",
      "/pages/ServiceCatalog",
      "/pages/TeamDashboard",
      "/pages/KnowledgeBase",
    ],
    "46-1": [
      "/pages/ServiceDashboard",
      "/pages/ServiceCatalog",
      "/pages/TeamDashboard",
      "/pages/KnowledgeBase",
    ],
  };

  function toSafeString(value) {
    return String(value == null ? "" : value).trim();
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function tryParseJson(input) {
    try {
      return JSON.parse(input);
    } catch (_) {
      return null;
    }
  }

  function getUserPayload() {
    var parsed = tryParseJson(
      (window.localStorage && window.localStorage.getItem("user_key")) || ""
    );
    var parsedValue =
      parsed && typeof parsed.value === "string"
        ? tryParseJson(parsed.value)
        : parsed && parsed.value;
    return (
      (parsedValue && typeof parsedValue === "object" && parsedValue) ||
      (parsed && typeof parsed === "object" && parsed) ||
      {}
    );
  }

  function getEmployeeGuidFromStorage() {
    var payload = getUserPayload();
    return toSafeString(payload.employeeguid || payload.EmployeeGUID || "");
  }

  function readStorageRawValue(key) {
    if (!window.localStorage) return "";
    var raw = window.localStorage.getItem(key);
    if (raw == null && window.sessionStorage) {
      raw = window.sessionStorage.getItem(key);
    }
    if (raw == null || raw === "") return "";
    var parsed = tryParseJson(raw);
    if (parsed && typeof parsed === "object" && parsed.value != null) {
      return String(parsed.value).trim();
    }
    if (typeof parsed === "string") return parsed.trim();
    return String(raw).trim();
  }

  function getNewLPFromStorage() {
    var keys = ["NewLP", "newLP", "newlp"];
    var index;
    for (index = 0; index < keys.length; index += 1) {
      var direct = readStorageRawValue(keys[index]);
      if (direct) return direct;
    }

    var userRaw = readStorageRawValue("user_key");
    var userParsed = tryParseJson(userRaw);
    var userValue =
      userParsed && typeof userParsed === "object" && userParsed.value != null
        ? userParsed.value
        : userParsed;
    if (typeof userValue === "string") {
      userParsed = tryParseJson(userValue) || userParsed;
      userValue =
        userParsed && typeof userParsed === "object" && userParsed.value != null
          ? userParsed.value
          : userParsed;
    }
    if (userValue && typeof userValue === "object") {
      var nested =
        userValue.NewLP || userValue.newLP || userValue.newlp || userValue.LP || "";
      if (nested) return String(nested).trim();
    }

    return "";
  }

  function parsePermissionCodes(newLP) {
    return toSafeString(newLP)
      .split(",")
      .map(function (code) {
        return code.trim();
      })
      .filter(Boolean);
  }

  function hasUnrestrictedTicketAccess(newLP) {
    var normalized = toSafeString(newLP);
    if (normalized === "11" || normalized === "46-3") return true;
    var codes = parsePermissionCodes(normalized);
    return codes.indexOf("11") >= 0 || codes.indexOf("46-3") >= 0;
  }

  function parseAppPermissions(raw) {
    var value = raw;
    if (value == null || value === "") return [];
    if (Array.isArray(value)) return value;
    if (typeof value === "string") {
      var parsed = tryParseJson(value);
      if (Array.isArray(parsed)) return parsed;
      if (typeof parsed === "string") {
        var reparsed = tryParseJson(parsed);
        if (Array.isArray(reparsed)) return reparsed;
      }
    }
    return [];
  }

  function isTicketFormVisible(row, newLP, employeeGuid) {
    if (hasUnrestrictedTicketAccess(newLP)) return true;

    var permissions = parseAppPermissions(
      pickField(row, ["AppPermissions", "appPermissions"])
    );
    if (!permissions.length) return false;

    var guid = toSafeString(employeeGuid).toLowerCase();
    var index;
    for (index = 0; index < permissions.length; index += 1) {
      var perm = permissions[index];
      if (!perm || typeof perm !== "object") continue;
      var userId = toSafeString(perm.UserID || perm.userId || perm.userID);
      if (!userId) continue;
      if (userId.toUpperCase() === "ALL") return true;
      if (guid && userId.toLowerCase() === guid) return true;
    }
    return false;
  }

  function filterRowsByAppPermissions(rows, newLP, employeeGuid) {
    return (Array.isArray(rows) ? rows : []).filter(function (row) {
      return isTicketFormVisible(row, newLP, employeeGuid);
    });
  }

  function normalizeBaseUrl(raw) {
    var value = toSafeString(raw);
    if (!value) return "";
    value = value.replace(/\/+$/, "");
    if (!/^https?:\/\//i.test(value)) {
      value = "https://" + value.replace(/^\/+/, "");
    }
    return value;
  }

  function getApiBaseUrl() {
    var fromStorage = toSafeString(
      window.localStorage && window.localStorage.getItem("env")
    );
    if (fromStorage) return normalizeBaseUrl(fromStorage);
    var fromEnv = toSafeString(window.APP_ENV && window.APP_ENV.API_BASE_URL);
    if (fromEnv) return normalizeBaseUrl(fromEnv);
    return "";
  }

  function getPageBaseUrl() {
    var fromStorage = toSafeString(
      window.localStorage && window.localStorage.getItem("ma")
    );
    if (fromStorage) return normalizeBaseUrl(fromStorage);
    if (typeof window.location !== "undefined" && window.location.origin) {
      return normalizeBaseUrl(window.location.origin);
    }
    return "";
  }

  function normalizePagePath(path) {
    return toSafeString(path).toLowerCase();
  }

  function getAllowedPagePaths(newLP) {
    var normalized = toSafeString(newLP);
    if (normalized === "11") {
      return HELPDESK_PAGE_PATHS.slice();
    }

    var allowed = {};
    parsePermissionCodes(normalized).forEach(function (code) {
      var pages = HELPDESK_PERMISSION_PAGES[code];
      if (!Array.isArray(pages)) return;
      pages.forEach(function (path) {
        allowed[normalizePagePath(path)] = path;
      });
    });

    return Object.keys(allowed).map(function (key) {
      return allowed[key];
    });
  }

  function hasCurrentPageAccess(newLP) {
    var target = normalizePagePath(CURRENT_PAGE_PATH);
    var allowedPaths = getAllowedPagePaths(newLP);
    var index;
    for (index = 0; index < allowedPaths.length; index += 1) {
      if (normalizePagePath(allowedPaths[index]) === target) return true;
    }
    return false;
  }

  function buildUnauthorizedRedirectUrl() {
    return getPageBaseUrl() + "/not-found?unauthorized=un";
  }

  function hidePageContent() {
    var root = document.getElementById("servPageRoot");
    if (root) root.style.visibility = "hidden";
  }

  function showPageContent() {
    var root = document.getElementById("servPageRoot");
    if (root) root.style.visibility = "";
  }

  function paintNavDockPlaceholder() {
    var list = document.getElementById("qafNavdockList");
    var api = window.QafNavDock;
    if (!list || !api || !Array.isArray(api.defaults) || !api.defaults.length) return;

    list.innerHTML = api.defaults
      .slice()
      .sort(function (a, b) {
        return Number(a.sequence || 0) - Number(b.sequence || 0);
      })
      .map(function (item) {
        var label = escapeHtml(item.displayName || "");
        var iconClass = escapeHtml(item.icon || "fa fa-circle");
        var iconColor = escapeHtml(item.iconColor || "#000000");
        var hasSubMenus = Array.isArray(item.subMenus) && item.subMenus.length > 0;
        var activeClass =
          !hasSubMenus && normalizePagePath(item.navigateTo) === normalizePagePath(CURRENT_PAGE_PATH)
            ? " is-active"
            : "";
        return (
          '<div class="qaf-navdock__item"' +
          (hasSubMenus ? ' data-has-submenu="true"' : "") +
          '>' +
          '<a class="qaf-navdock__link' +
          activeClass +
          '" href="#">' +
          '<i class="qaf-navdock__icon ' +
          iconClass +
          '" style="color:' +
          iconColor +
          ';" aria-hidden="true"></i>' +
          '<span class="qaf-navdock__label">' +
          label +
          "</span>" +
          (hasSubMenus
            ? '<i class="qaf-navdock__chevron fa fa-angle-down" aria-hidden="true"></i>'
            : "") +
          "</a>" +
          "</div>"
        );
      })
      .join("");
  }

  function scheduleNavDockInitWhenReady() {
    if (window.__servCatalogNavInitScheduled) return;
    window.__servCatalogNavInitScheduled = true;

    var attempts = 0;
    var maxAttempts = 40;
    var timer = setInterval(function () {
      attempts += 1;
      if (!getNewLPFromStorage()) {
        if (attempts >= maxAttempts) clearInterval(timer);
        return;
      }
      clearInterval(timer);
      window.__servCatalogNavInitScheduled = false;
      initNavDock();
    }, 50);
  }

  function enforcePageAccess() {
    if (!hasCurrentPageAccess(getNewLPFromStorage())) {
      window.location.replace(buildUnauthorizedRedirectUrl());
      return false;
    }
    return true;
  }

  function getAuthHeaders() {
    var payload = getUserPayload();
    return {
      Accept: "application/json",
      "Content-Type": "application/json",
      employeeguid: payload.employeeguid || payload.EmployeeGUID || "",
      hrzemail: payload.hrzemail || payload.Email || "",
      hrzempid: payload.hrzempid || payload.EmployeeID || "",
      lngs: payload.lngs || "Asia/Kolkata",
    };
  }

  function getQafService() {
    return window.QafService || (window.parent && window.parent.QafService) || null;
  }

  function extractRows(payload) {
    if (Array.isArray(payload)) return payload;
    if (!payload || typeof payload !== "object") return [];
    if (Array.isArray(payload.Items)) return payload.Items;
    if (Array.isArray(payload.Data)) return payload.Data;
    if (Array.isArray(payload.Value)) return payload.Value;
    if (payload.value && Array.isArray(payload.value)) return payload.value;
    if (payload.data && Array.isArray(payload.data)) return payload.data;
    if (payload.result && Array.isArray(payload.result)) return payload.result;
    if (payload.rows && Array.isArray(payload.rows)) return payload.rows;
    if (payload.items && Array.isArray(payload.items)) return payload.items;
    if (Array.isArray(payload.ConfigList)) return payload.ConfigList;
    if (Array.isArray(payload.WorkflowConfigList)) return payload.WorkflowConfigList;
    return [];
  }

  function normalizeCategoryRows(payload) {
    var rows = extractRows(payload);
    return rows.map(function (row) {
      if (!row || typeof row !== "object") return row;
      var out = Object.assign({}, row);
      var rfv = Array.isArray(row.RecordFieldValues) ? row.RecordFieldValues : [];
      rfv.forEach(function (item) {
        var key = toSafeString(
          item.FieldInternalName || item.FieldName || item.DisplayName || item.name
        );
        if (!key) return;
        var val =
          item.UGFieldValue != null
            ? item.UGFieldValue
            : item.FieldValue != null
              ? item.FieldValue
              : item.Value;
        if (out[key] == null || out[key] === "") out[key] = val;
      });
      return out;
    });
  }

  function pickField(row, keys) {
    if (!row || typeof row !== "object") return "";
    for (var i = 0; i < keys.length; i += 1) {
      var val = row[keys[i]];
      if (val != null && String(val).trim() !== "") return String(val).trim();
    }
    return "";
  }

  function isTruthyDisabled(value) {
    if (value === true || value === 1) return true;
    var text = String(value == null ? "" : value).trim().toLowerCase();
    return text === "true" || text === "1" || text === "yes";
  }

  function buildAppIconSrc(appIconValue) {
    var appIcon = toSafeString(appIconValue);
    if (!appIcon) return DEFAULT_APP_ICON;
    return "/Attachment/downloadfile?fileUrl=" + encodeURIComponent(appIcon);
  }

  function normalizeWorkflowApps(rows) {
    return (Array.isArray(rows) ? rows : [])
      .filter(function (row) {
        return row && !isTruthyDisabled(pickField(row, ["IsDisabled", "isDisabled"]));
      })
      .map(function (row, index) {
        return {
          id: pickField(row, ["WFID", "WfId", "wfId", "Id", "ID"]) || "app-" + index,
          appIcon: buildAppIconSrc(pickField(row, ["AppIcon", "appIcon"])),
          appTitle: pickField(row, ["AppTitle", "appTitle", "Title", "WFName", "WfName"]),
          appDescription: pickField(row, [
            "AppDescription",
            "appDescription",
            "Description",
          ]),
          appCategory: pickField(row, ["AppCategory", "appCategory", "CategoryID"]),
          wfId: pickField(row, ["WFID", "WfId", "wfId"]),
          wfName: pickField(row, ["WFName", "WfName", "wfName"]),
          objectName: pickField(row, ["ObjectName", "objectName"]),
          objectId: pickField(row, ["ObjectID", "ObjectId", "objectId"]),
        };
      })
      .filter(function (app) {
        return Boolean(app.appTitle);
      });
  }

  function normalizeCategories(rows) {
    return (Array.isArray(rows) ? rows : [])
      .map(function (row) {
        return {
          recordId: pickField(row, ["RecordID", "RecordId", "recordId", "ID", "Id"]),
          categoryName: pickField(row, ["CategoryName", "categoryName", "Name"]),
          sequence: Number(pickField(row, ["Sequence", "sequence"]) || 0),
        };
      })
      .filter(function (cat) {
        return Boolean(cat.recordId && cat.categoryName);
      })
      .sort(function (a, b) {
        return a.sequence - b.sequence;
      });
  }

  function fetchWorkflowConfigListOnce() {
    if (workflowConfigPromise) return workflowConfigPromise;

    workflowConfigPromise = (async function () {
      var base = getApiBaseUrl();
      var url =
        base +
        "/api/WorkflowConfigList?templateType=" +
        encodeURIComponent(WORKFLOW_TEMPLATE);
      var response = await fetch(url, {
        method: "GET",
        headers: getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error(
          "WorkflowConfigList failed (" + response.status + " " + response.statusText + ")"
        );
      }
      var payload = await response.json();
      if (payload === false) return [];
      var rows = extractRows(payload);
      var newLP = getNewLPFromStorage();
      var employeeGuid = getEmployeeGuidFromStorage();
      var wfResult = normalizeWorkflowApps(
        filterRowsByAppPermissions(rows, newLP, employeeGuid)
      );
      return wfResult;
    })().catch(function (error) {
      workflowConfigPromise = null;
      throw error;
    });

    return workflowConfigPromise;
  }

  function fetchCategoryRowsOnce() {
    if (categoryRowsPromise) return categoryRowsPromise;

    categoryRowsPromise = (async function () {
      var qafService = getQafService();
      if (qafService && typeof qafService.GetItems === "function") {
        var response = await qafService.GetItems(
          CATEGORY_REPOSITORY,
          CATEGORY_FIELDS,
          10000,
          1,
          "",
          "Sequence",
          true
        );
        return normalizeCategories(normalizeCategoryRows(response));
      }

      if (window.QafLibrary && typeof window.QafLibrary.fetchRepositoryData === "function") {
        var viaLibrary = await window.QafLibrary.fetchRepositoryData({
          objectName: CATEGORY_REPOSITORY,
          repositoryName: CATEGORY_REPOSITORY,
          fieldList: CATEGORY_FIELDS.join(","),
          pageSize: 10000,
          currentPage: 1,
          sortBy: "Sequence",
          isAscending: true,
        });
        return normalizeCategories(viaLibrary.rows || []);
      }

      throw new Error("QafService.GetItems is not available.");
    })().catch(function (error) {
      categoryRowsPromise = null;
      throw error;
    });

    return categoryRowsPromise;
  }

  function getAppsForRender() {
    return state.filteredApps != null ? state.filteredApps : state.apps;
  }

  var OTHER_CATEGORY_NAME = "Other";

  function buildOtherCategory(categories) {
    var maxSequence = 0;
    categories.forEach(function (cat) {
      var seq = Number(cat.sequence);
      if (!isNaN(seq) && seq > maxSequence) maxSequence = seq;
    });
    return {
      recordId: "",
      categoryName: OTHER_CATEGORY_NAME,
      sequence: maxSequence + 1,
    };
  }

  function buildCategorySections(categories, apps) {
    var appsByCategory = {};
    var uncategorizedApps = [];

    apps.forEach(function (app) {
      var key = toSafeString(app.appCategory);
      if (!key) {
        uncategorizedApps.push(app);
        return;
      }
      if (!appsByCategory[key]) appsByCategory[key] = [];
      appsByCategory[key].push(app);
    });

    var sections = categories
      .map(function (cat) {
        var list = appsByCategory[cat.recordId] || [];
        return { category: cat, apps: list };
      })
      .filter(function (section) {
        return section.apps.length > 0;
      });

    if (uncategorizedApps.length > 0) {
      sections.push({
        category: buildOtherCategory(categories),
        apps: uncategorizedApps,
      });
    }

    return sections;
  }

  function buildReportUrl(app) {
    var base = getPageBaseUrl();
    var params = new URLSearchParams();
    if (app.wfId) params.set("WFID", app.wfId);
    if (app.wfName) params.set("WFName", app.wfName);
    if (app.objectName) params.set("ObjectName", app.objectName);
    return (
      base +
      "/e-helpdesk/helpdesk-serivce-report?" +
      params.toString()
    );
  }

  function buildSettingUrl(app) {
    var base = getPageBaseUrl();
    var wfId = encodeURIComponent(app.wfId || "");
    var objectId = encodeURIComponent(app.objectId || "");
    return base + "/e-helpdesk/" + SETTING_PATH_PREFIX + "/" + wfId + "/" + objectId;
  }

  function buildDescTipId(appId) {
    return "serv-desc-tip-" + String(appId == null ? "" : appId).replace(/[^a-zA-Z0-9_-]/g, "");
  }

  function renderAppDescription(app) {
    var desc = escapeHtml(app.appDescription || "");
    if (!desc) {
      return '<p class="serv-app-card__desc"></p>';
    }
    var tipId = buildDescTipId(app.id);
    return (
      '<div class="serv-app-card__desc-wrap">' +
      '<p class="serv-app-card__desc" tabindex="0" aria-describedby="' +
      tipId +
      '">' +
      desc +
      "</p>" +
      '<span class="serv-app-card__desc-tip" id="' +
      tipId +
      '" role="tooltip">' +
      desc +
      "</span>" +
      "</div>"
    );
  }

  function renderAppCard(app) {
    var title = escapeHtml(app.appTitle);
    return (
      '<article class="card serv-app-card" data-app-id="' +
      escapeHtml(app.id) +
      '">' +
      '<div class="serv-app-card__head">' +
      '<img class="serv-app-card__icon" src="' +
      escapeHtml(app.appIcon) +
      '" width="40" height="40" alt="" loading="lazy" onerror="this.onerror=null;this.src=\'' +
      DEFAULT_APP_ICON +
      '\';" />' +
      '<div class="serv-app-card__text">' +
      '<h3 class="serv-app-card__title" data-action="open-form" tabindex="0" role="button">' +
      title +
      "</h3>" +
      renderAppDescription(app) +
      "</div>" +
      "</div>" +
      "</article>"
    );
  }

  function renderAppsPanel() {
    var host = document.getElementById("servAppsHost");
    var statusEl = document.getElementById("servAppsStatus");
    if (!host) return;

    var apps = getAppsForRender();
    var sections = buildCategorySections(state.categories, apps);

    if (!sections.length) {
      host.innerHTML =
        '<p class="text-muted serv-apps-status" id="servAppsStatus">' +
        (state.searchQuery
          ? "No services match your search."
          : "No services available.") +
        "</p>";
      return;
    }

    if (statusEl) statusEl.remove();

    host.innerHTML = sections
      .map(function (section) {
        var cards = section.apps.map(renderAppCard).join("");
        return (
          '<section class="serv-category">' +
          '<h2 class="serv-category__name">' +
          escapeHtml(section.category.categoryName) +
          "</h2>" +
          '<div class="serv-category__grid">' +
          cards +
          "</div>" +
          "</section>"
        );
      })
      .join("");
  }

  function setPageBusy(isBusy) {
    var root = document.getElementById("servPageRoot");
    if (root) root.setAttribute("aria-busy", String(Boolean(isBusy)));
  }

  function setStatusMessage(message) {
    var host = document.getElementById("servAppsHost");
    if (!host) return;
    host.innerHTML =
      '<p class="text-muted serv-apps-status" id="servAppsStatus">' +
      escapeHtml(message) +
      "</p>";
  }

  function findAppByCardElement(cardEl) {
    var appId = cardEl && cardEl.getAttribute("data-app-id");
    if (!appId) return null;
    return state.apps.find(function (app) {
      return app.id === appId;
    });
  }

  function openAppForm(app, onDone) {
    if (!app) return;
    var safeOnDone = typeof onDone === "function" ? onDone : function () {};
    var objectName = app.objectName;
    var objectId = app.objectId;
    if (window.QafPageService && typeof window.QafPageService.AddItem === "function") {
      if (objectName) {
        window.QafPageService.AddItem(objectName, safeOnDone);
        return;
      }
      if (objectId) {
        window.QafPageService.AddItem(objectId, safeOnDone);
        return;
      }
    }
    if (window.QafLibrary && typeof window.QafLibrary.openAddForm === "function") {
      window.QafLibrary.openAddForm({
        repositoryName: objectName || objectId,
        objectID: objectId,
        objectId: objectId,
        onDone: safeOnDone,
      });
    }
  }

  function handleCardAction(action, app) {
    if (!app) return;
    if (action === "open-form") {
      openAppForm(app);
      return;
    }
    if (action === "report") {
      window.open(buildReportUrl(app), "_blank", "noopener,noreferrer");
      return;
    }
    if (action === "setting") {
      window.location.assign(buildSettingUrl(app));
    }
  }

  function applySearch(query) {
    var q = toSafeString(query).toLowerCase();
    state.searchQuery = q;
    if (!q) {
      state.filteredApps = null;
      renderAppsPanel();
      return;
    }
    state.filteredApps = state.apps.filter(function (app) {
      var title = toSafeString(app.appTitle).toLowerCase();
      var desc = toSafeString(app.appDescription).toLowerCase();
      return title.indexOf(q) >= 0 || desc.indexOf(q) >= 0;
    });
    renderAppsPanel();
  }

  function updateSearchClearVisibility() {
    var input = document.getElementById("servSearchInput");
    var clearBtn = document.getElementById("servSearchClear");
    if (!input || !clearBtn) return;
    if (input.value.length > 0) clearBtn.removeAttribute("hidden");
    else clearBtn.setAttribute("hidden", "");
  }

  function bindSearch() {
    var input = document.getElementById("servSearchInput");
    var clearBtn = document.getElementById("servSearchClear");
    if (!input) return;

    input.addEventListener("keydown", function (event) {
      if (event.key !== "Enter") return;
      event.preventDefault();
      applySearch(input.value);
    });

    input.addEventListener("input", function () {
      updateSearchClearVisibility();
    });

    if (clearBtn) {
      clearBtn.addEventListener("click", function () {
        input.value = "";
        updateSearchClearVisibility();
        applySearch("");
        input.focus();
      });
    }
  }

  function bindAppsHost() {
    var host = document.getElementById("servAppsHost");
    if (!host || host.__servAppsBound) return;
    host.__servAppsBound = true;

    host.addEventListener("click", function (event) {
      var titleEl = event.target.closest("[data-action='open-form']");
      var actionEl = event.target.closest("[data-action]");
      var card = event.target.closest(".serv-app-card");
      if (!card) return;

      var app = findAppByCardElement(card);
      if (!app) return;

      if (titleEl) {
        event.preventDefault();
        handleCardAction("open-form", app);
        return;
      }

      if (!actionEl) return;
      var action = actionEl.getAttribute("data-action");
      if (action === "noop") return;
      event.preventDefault();
      handleCardAction(action, app);
    });

    host.addEventListener("keydown", function (event) {
      if (event.key !== "Enter" && event.key !== " ") return;
      var titleEl = event.target.closest("[data-action='open-form']");
      if (!titleEl) return;
      event.preventDefault();
      var card = titleEl.closest(".serv-app-card");
      var app = findAppByCardElement(card);
      handleCardAction("open-form", app);
    });
  }

  function initNavDock() {
    if (!document.getElementById("qafNavdockList")) return;
    var api = window.QafNavDock;
    if (!api || typeof api.init !== "function") return;

    if (!getNewLPFromStorage()) {
      paintNavDockPlaceholder();
      scheduleNavDockInitWhenReady();
      return;
    }

    api.init({
      toggleElementId: "qafNavToggle",
      listElementId: "qafNavdockList",
    });
  }

  async function loadPageData() {
    setPageBusy(true);
    setStatusMessage("Loading services...");
    try {
      var results = await Promise.all([
        fetchWorkflowConfigListOnce(),
        fetchCategoryRowsOnce(),
      ]);
      state.apps = results[0];
      state.categories = results[1];
      state.filteredApps = null;
      renderAppsPanel();
    } catch (error) {
      var msg =
        error && error.message ? error.message : "Unable to load services.";
      setStatusMessage(msg);
    } finally {
      setPageBusy(false);
    }
  }

  function onDocumentReady(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  // Exposed so other pages (Service Dashboard, Team Dashboard) can reuse the
  // exact same workflow discovery/permission/config rules and OOTB
  // form-opening mechanism as the Service Catalog, instead of
  // re-implementing them. Safe to load on any page: everything below this
  // point only runs when the Service Catalog's own root element is present.
  window.QafServiceCatalog = window.QafServiceCatalog || {};
  window.QafServiceCatalog.getAvailableApps = fetchWorkflowConfigListOnce;
  window.QafServiceCatalog.openAppForm = openAppForm;

  function isServiceCatalogPageActive() {
    return Boolean(document.getElementById("servPageRoot"));
  }

  if (isServiceCatalogPageActive()) {
    hidePageContent();
    paintNavDockPlaceholder();

    onDocumentReady(function () {
      paintNavDockPlaceholder();
      if (!enforcePageAccess()) return;
      showPageContent();
      initNavDock();
      bindSearch();
      bindAppsHost();
      updateSearchClearVisibility();
      loadPageData();
    });
  }
})();