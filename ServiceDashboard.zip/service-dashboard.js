(function () {
  "use strict";

  var WORKFLOW_TEMPLATE = "ehelpdesk";
  var STATUS_REPOSITORY = "Helpdesk_Status";
  var STATUS_FIELDS = ["StatusName", "RecordID"];
  var DEFAULT_APP_ICON = "/SmartHR/assets/img/default_service.png";
  var REQUEST_TYPE_WF_PROCEDURE = "ITSM_Helpdesk_Employee_WFName";

  // Tenant-configurable request type labels (update here when tenant changes)
  var REQUEST_TYPE_NAMES = {
    incident: "IT Incident Request",
    service: "IT Service Request",
    change: "IT Change Request",
    problem: "IT Problem Request",
  };

  // API AppTitle / WFName values that differ from REQUEST_TYPE_NAMES (per tenant)
  var REQUEST_TYPE_APP_ALIASES = {
    incident: [],
    service: [],
    change: [],
    problem: [],
  };

  function buildMatcherPatterns(typeKey) {
    var patterns = [];
    var seen = {};
    function add(value) {
      var text = String(value == null ? "" : value).trim().toLowerCase();
      if (!text || seen[text]) return;
      seen[text] = true;
      patterns.push(text);
      var underscore = text.replace(/\s+/g, "_");
      if (underscore !== text && !seen[underscore]) {
        seen[underscore] = true;
        patterns.push(underscore);
      }
    }
    add(REQUEST_TYPE_NAMES[typeKey]);
    (REQUEST_TYPE_APP_ALIASES[typeKey] || []).forEach(add);
    return patterns;
  }

  function buildAllRequestTypeFilterTerms(typeKey) {
    var terms = [];
    var seen = {};
    function addTerms(name) {
      buildRequestTypeFilterTerms(name).forEach(function (term) {
        if (!term || seen[term]) return;
        seen[term] = true;
        terms.push(term);
      });
    }
    addTerms(REQUEST_TYPE_NAMES[typeKey]);
    (REQUEST_TYPE_APP_ALIASES[typeKey] || []).forEach(addTerms);
    return terms;
  }

  function buildRequestTypeFilterTerms(name) {
    var label = toSafeString(name);
    if (!label) return [];
    var underscore = label.replace(/\s+/g, "_");
    return underscore === label ? [label] : [label, underscore];
  }

  var DASHBOARD_APP_MATCHERS = [
    {
      key: "change",
      label: REQUEST_TYPE_NAMES.change,
      patterns: buildMatcherPatterns("change"),
    },
    {
      key: "service",
      label: REQUEST_TYPE_NAMES.service,
      patterns: buildMatcherPatterns("service"),
    },
    {
      key: "problem",
      label: REQUEST_TYPE_NAMES.problem,
      patterns: buildMatcherPatterns("problem"),
    },
    {
      key: "incident",
      label: REQUEST_TYPE_NAMES.incident,
      patterns: buildMatcherPatterns("incident"),
    },
  ];

  var REQUEST_TYPE_FILTERS = {
    [REQUEST_TYPE_NAMES.change]: buildAllRequestTypeFilterTerms("change"),
    [REQUEST_TYPE_NAMES.service]: buildAllRequestTypeFilterTerms("service"),
    [REQUEST_TYPE_NAMES.problem]: buildAllRequestTypeFilterTerms("problem"),
    [REQUEST_TYPE_NAMES.incident]: buildAllRequestTypeFilterTerms("incident"),
  };

  var REQUEST_TYPE_TICKET_PREFIXES = {
    [REQUEST_TYPE_NAMES.change]: ["CR-"],
    [REQUEST_TYPE_NAMES.service]: ["SR-"],
    [REQUEST_TYPE_NAMES.problem]: ["PR-"],
    [REQUEST_TYPE_NAMES.incident]: ["INR-"],
  };

  var TABLE_COLUMNS = [
    { key: "ticketId", label: "Ticket ID", field: "TicketID", sortType: "text" },
    { key: "requestTitle", label: "Request Title", field: "RequestTitle", sortType: "text" },
    { key: "ticketType", label: "Ticket Type", field: "RequestType", sortType: "text" },
    { key: "requester", label: "Requester", field: "Requester", sortType: "text" },
    { key: "priority", label: "Priority", field: "Priority", sortType: "text", badge: "priority" },
    { key: "dueDate", label: "Due Date", field: "DueDate", sortType: "date" },
    { key: "assignedTo", label: "Technician", field: "AssignedTo", sortType: "text" },
    { key: "assignedTeam", label: "Team", field: "PendingWithTeamName", sortType: "text" },
    { key: "status", label: "Status", field: "Status", sortType: "text", badge: "status" },
    { key: "createdDate", label: "Created Date", field: "CreatedDate", sortType: "date" },
  ];

  var CURRENT_PAGE_PATH = "/pages/ServiceDashboard";

  var HELPDESK_PAGE_PATHS = [
    "/pages/ServiceDashboard",
    "/pages/ServiceCatalog",
    "/pages/KnowledgeBase",
    "/pages/TeamDashboard",
    "/pages/ReportAndAnalytics",
    "/pages/HelpdeskPermission",
    "/pages/HelpdeskStatus",
    "/pages/HelpdeskPriority",
  ];

  var HELPDESK_PERMISSION_PAGES = {
    "46-3": [
      "/pages/ServiceDashboard",
      "/pages/ServiceCatalog",
      "/pages/KnowledgeBase",
      "/pages/TeamDashboard",
      "/pages/ReportAndAnalytics",
      "/pages/HelpdeskPermission",
      "/pages/HelpdeskStatus",
      "/pages/HelpdeskPriority",
    ],
    "46-2": [
      "/pages/ServiceDashboard",
      "/pages/ServiceCatalog",
      "/pages/TeamDashboard",
      "/pages/KnowledgeBase",
    ],
    "46-1": [
      "/pages/ServiceDashboard",
      "/pages/ServiceCatalog",
      "/pages/TeamDashboard",
      "/pages/KnowledgeBase",
    ],
  };

  var workflowConfigPromise = null;
  var statusRowsPromise = null;
  var myServicesFetchToken = 0;

  var RECORD_ID_KEYS = [
    "RecordID",
    "Record Id",
    "RecordId",
    "recordId",
    "recordid",
    "RID",
    "rid",
    "ID",
    "Id",
    "id",
    "RequestRecordID",
    "RequestRecordId",
    "ItemID",
    "ItemId",
    "WorkflowRecordID",
    "WorkflowRecordId",
    "ParentRecordID",
    "ParentRecordId",
  ];

  var OBJECT_ID_KEYS = [
    "ObjectID",
    "ObjectId",
    "objectId",
    "objectid",
    "OID",
    "oid",
    "WFObjectID",
    "WFObjectId",
    "RepositoryObjectID",
    "RepositoryObjectId",
  ];

  var INSTANCE_ID_KEYS = [
    "InstanceID",
    "Instance Id",
    "InstanceId",
    "instanceId",
    "instanceid",
    "INCID",
    "incid",
    "WFInstanceID",
    "WFInstanceId",
    "WorkflowInstanceID",
    "WorkflowInstanceId",
    "RequestInstanceID",
    "RequestInstanceId",
    "ProcessInstanceID",
    "ProcessInstanceId",
  ];

  var state = {
    apps: [],
    workflowConfigs: [],
    statusOptions: [],
    typeOptions: [],
    typeOptionsLoaded: false,
    newApps: [],
    newAppsLoaded: false,
    newAppsError: false,
    allTickets: [],
    filteredTickets: [],
    filters: {
      statusRecordId: "",
      statusName: "",
      requestType: "",
      searchQuery: "",
    },
  };

  var gridTableInstance = null;
  var typeOptionsPromise = null;
  var newAppOptionsPromise = null;

  function toSafeString(value) {
    return String(value == null ? "" : value).trim();
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function tryParseJson(input) {
    try {
      return JSON.parse(input);
    } catch (_) {
      return null;
    }
  }

  function getUserPayload() {
    var parsed = tryParseJson(
      (window.localStorage && window.localStorage.getItem("user_key")) || ""
    );
    var parsedValue =
      parsed && typeof parsed.value === "string"
        ? tryParseJson(parsed.value)
        : parsed && parsed.value;
    return (
      (parsedValue && typeof parsedValue === "object" && parsedValue) ||
      (parsed && typeof parsed === "object" && parsed) ||
      {}
    );
  }

  function getEmployeeGuid() {
    var payload = getUserPayload();
    return toSafeString(payload.EmployeeGUID || payload.employeeguid || payload.employeeGuid);
  }

  function readStorageRawValue(key) {
    if (!window.localStorage) return "";
    var raw = window.localStorage.getItem(key);
    if (raw == null && window.sessionStorage) {
      raw = window.sessionStorage.getItem(key);
    }
    if (raw == null || raw === "") return "";
    var parsed = tryParseJson(raw);
    if (parsed && typeof parsed === "object" && parsed.value != null) {
      return String(parsed.value).trim();
    }
    if (typeof parsed === "string") return parsed.trim();
    return String(raw).trim();
  }

  function getNewLPFromStorage() {
    var keys = ["NewLP", "newLP", "newlp"];
    var index;
    for (index = 0; index < keys.length; index += 1) {
      var direct = readStorageRawValue(keys[index]);
      if (direct) return direct;
    }

    var userRaw = readStorageRawValue("user_key");
    var userParsed = tryParseJson(userRaw);
    var userValue =
      userParsed && typeof userParsed === "object" && userParsed.value != null
        ? userParsed.value
        : userParsed;
    if (typeof userValue === "string") {
      userParsed = tryParseJson(userValue) || userParsed;
      userValue =
        userParsed && typeof userParsed === "object" && userParsed.value != null
          ? userParsed.value
          : userParsed;
    }
    if (userValue && typeof userValue === "object") {
      var nested =
        userValue.NewLP || userValue.newLP || userValue.newlp || userValue.LP || "";
      if (nested) return String(nested).trim();
    }

    return "";
  }

  function parsePermissionCodes(newLP) {
    return toSafeString(newLP)
      .split(",")
      .map(function (code) {
        return code.trim();
      })
      .filter(Boolean);
  }

  function hasUnrestrictedTicketAccess(newLP) {
    var normalized = toSafeString(newLP);
    if (normalized === "11" || normalized === "46-3") return true;
    var codes = parsePermissionCodes(normalized);
    return codes.indexOf("11") >= 0 || codes.indexOf("46-3") >= 0;
  }

  function parseAppPermissions(raw) {
    var value = raw;
    if (value == null || value === "") return [];
    if (Array.isArray(value)) return value;
    if (typeof value === "string") {
      var parsed = tryParseJson(value);
      if (Array.isArray(parsed)) return parsed;
      if (typeof parsed === "string") {
        var reparsed = tryParseJson(parsed);
        if (Array.isArray(reparsed)) return reparsed;
      }
    }
    return [];
  }

  function normalizeBaseUrl(raw) {
    var value = toSafeString(raw);
    if (!value) return "";
    value = value.replace(/\/+$/, "");
    if (!/^https?:\/\//i.test(value)) {
      value = "https://" + value.replace(/^\/+/, "");
    }
    return value;
  }

  function getApiBaseUrl() {
    var fromStorage = toSafeString(
      window.localStorage && window.localStorage.getItem("env")
    );
    if (fromStorage) return normalizeBaseUrl(fromStorage);
    var fromEnv = toSafeString(window.APP_ENV && window.APP_ENV.API_BASE_URL);
    if (fromEnv) return normalizeBaseUrl(fromEnv);
    return "";
  }

  function getPageBaseUrl() {
    var fromStorage = toSafeString(
      window.localStorage && window.localStorage.getItem("ma")
    );
    if (fromStorage) return normalizeBaseUrl(fromStorage);
    if (typeof window.location !== "undefined" && window.location.origin) {
      return normalizeBaseUrl(window.location.origin);
    }
    return "";
  }

  function normalizePagePath(path) {
    return toSafeString(path).toLowerCase();
  }

  function getAllowedPagePaths(newLP) {
    var normalized = toSafeString(newLP);
    if (normalized === "11") {
      return HELPDESK_PAGE_PATHS.slice();
    }

    var allowed = {};
    parsePermissionCodes(normalized).forEach(function (code) {
      var pages = HELPDESK_PERMISSION_PAGES[code];
      if (!Array.isArray(pages)) return;
      pages.forEach(function (path) {
        allowed[normalizePagePath(path)] = path;
      });
    });

    return Object.keys(allowed).map(function (key) {
      return allowed[key];
    });
  }

  function hasCurrentPageAccess(newLP) {
    var target = normalizePagePath(CURRENT_PAGE_PATH);
    var allowedPaths = getAllowedPagePaths(newLP);
    var index;
    for (index = 0; index < allowedPaths.length; index += 1) {
      if (normalizePagePath(allowedPaths[index]) === target) return true;
    }
    return false;
  }

  function buildUnauthorizedRedirectUrl() {
    return getPageBaseUrl() + "/not-found?unauthorized=un";
  }

  function hidePageContent() {
    var root = document.getElementById("servdashPageRoot");
    if (root) root.style.visibility = "hidden";
  }

  function showPageContent() {
    var root = document.getElementById("servdashPageRoot");
    if (root) root.style.visibility = "";
  }

  function paintNavDockPlaceholder() {
    var list = document.getElementById("qafNavdockList");
    var api = window.QafNavDock;
    if (!list || !api || !Array.isArray(api.defaults) || !api.defaults.length) return;

    list.innerHTML = api.defaults
      .slice()
      .sort(function (a, b) {
        return Number(a.sequence || 0) - Number(b.sequence || 0);
      })
      .map(function (item) {
        var label = escapeHtml(item.displayName || "");
        var iconClass = escapeHtml(item.icon || "fa fa-circle");
        var iconColor = escapeHtml(item.iconColor || "#000000");
        var hasSubMenus = Array.isArray(item.subMenus) && item.subMenus.length > 0;
        var activeClass =
          !hasSubMenus && normalizePagePath(item.navigateTo) === normalizePagePath(CURRENT_PAGE_PATH)
            ? " is-active"
            : "";
        return (
          '<div class="qaf-navdock__item"' +
          (hasSubMenus ? ' data-has-submenu="true"' : "") +
          '>' +
          '<a class="qaf-navdock__link' +
          activeClass +
          '" href="#">' +
          '<i class="qaf-navdock__icon ' +
          iconClass +
          '" style="color:' +
          iconColor +
          ';" aria-hidden="true"></i>' +
          '<span class="qaf-navdock__label">' +
          label +
          "</span>" +
          (hasSubMenus
            ? '<i class="qaf-navdock__chevron fa fa-angle-down" aria-hidden="true"></i>'
            : "") +
          "</a>" +
          "</div>"
        );
      })
      .join("");
  }

  function scheduleNavDockInitWhenReady() {
    if (window.__servdashNavInitScheduled) return;
    window.__servdashNavInitScheduled = true;

    var attempts = 0;
    var maxAttempts = 40;
    var timer = setInterval(function () {
      attempts += 1;
      if (!getNewLPFromStorage()) {
        if (attempts >= maxAttempts) clearInterval(timer);
        return;
      }
      clearInterval(timer);
      window.__servdashNavInitScheduled = false;
      initNavDock();
    }, 50);
  }

  function enforcePageAccess() {
    if (!hasCurrentPageAccess(getNewLPFromStorage())) {
      window.location.replace(buildUnauthorizedRedirectUrl());
      return false;
    }
    return true;
  }

  function getAuthHeaders() {
    var payload = getUserPayload();
    return {
      Accept: "application/json",
      "Content-Type": "application/json",
      employeeguid: payload.employeeguid || payload.EmployeeGUID || "",
      hrzemail: payload.hrzemail || payload.Email || "",
      hrzempid: payload.hrzempid || payload.EmployeeID || "",
      // Outbound request header only - NOT display formatting. Left as-is on
      // purpose: changing it may change what the API returns. Display
      // conversion is driven entirely by CS_SETTING.TimeZone.
      lngs: payload.lngs || "Asia/Kolkata",
    };
  }

  function getQafService() {
    return window.QafService || (window.parent && window.parent.QafService) || null;
  }

  function extractRows(payload) {
    if (Array.isArray(payload)) return payload;
    if (!payload || typeof payload !== "object") return [];
    if (Array.isArray(payload.Items)) return payload.Items;
    if (Array.isArray(payload.Data)) return payload.Data;
    if (Array.isArray(payload.Value)) return payload.Value;
    if (payload.value && Array.isArray(payload.value)) return payload.value;
    if (payload.data && Array.isArray(payload.data)) return payload.data;
    if (payload.result && Array.isArray(payload.result)) return payload.result;
    if (payload.rows && Array.isArray(payload.rows)) return payload.rows;
    if (payload.items && Array.isArray(payload.items)) return payload.items;
    if (Array.isArray(payload.ConfigList)) return payload.ConfigList;
    if (Array.isArray(payload.WorkflowConfigList)) return payload.WorkflowConfigList;
    if (Array.isArray(payload.MyServices)) return payload.MyServices;
    if (Array.isArray(payload.ServiceItems)) return payload.ServiceItems;
    if (Array.isArray(payload.Records)) return payload.Records;
    if (Array.isArray(payload.MyServiceList)) return payload.MyServiceList;
    if (Array.isArray(payload.Tickets)) return payload.Tickets;
    return [];
  }

  function flattenTicketSourceRow(row) {
    if (!row || typeof row !== "object") return {};
    var flat = normalizeCategoryRows([row])[0] || Object.assign({}, row);
    var nestedKeys = [
      "Record",
      "record",
      "Item",
      "item",
      "Data",
      "data",
      "Ticket",
      "ticket",
      "Row",
      "row",
      "ServiceItem",
      "serviceItem",
    ];
    nestedKeys.forEach(function (key) {
      var nested = flat[key];
      if (nested && typeof nested === "object" && !Array.isArray(nested)) {
        flat = Object.assign({}, nested, flat);
      }
    });
    return flat;
  }

  function normalizeFieldKey(value) {
    return String(value || "")
      .replace(/[^a-z0-9]/gi, "")
      .toLowerCase();
  }

  function inferGuidRoleFromKey(key) {
    var norm = normalizeFieldKey(key);
    if (!norm) return "";
    if (norm.indexOf("objectid") >= 0 || norm === "oid") return "object";
    if (norm.indexOf("instanceid") >= 0 || norm === "incid" || norm.indexOf("wfinstance") >= 0)
      return "instance";
    if (
      norm.indexOf("recordid") >= 0 ||
      norm === "rid" ||
      norm === "itemid" ||
      norm.indexOf("requestrecord") >= 0
    )
      return "record";
    if (norm === "id" || norm.endsWith("id")) return "unknown";
    return "";
  }

  function resolveTicketLinkIds(row) {
    var flat = flattenTicketSourceRow(row);
    var ids = {
      objectId: pickLinkField(flat, OBJECT_ID_KEYS),
      recordId: pickLinkField(flat, RECORD_ID_KEYS),
      instanceId: pickLinkField(flat, INSTANCE_ID_KEYS),
    };

    var collected = [];
    var seen = {};

    function collectFromValue(value, keyHint) {
      if (value == null) return;
      if (typeof value === "object") {
        if (Array.isArray(value)) {
          value.forEach(function (item, index) {
            collectFromValue(item, keyHint + "[" + index + "]");
          });
          return;
        }
        Object.keys(value).forEach(function (childKey) {
          collectFromValue(value[childKey], childKey);
        });
        return;
      }
      var guid = extractRecordGuid(value);
      if (!guid || seen[guid]) return;
      seen[guid] = true;
      collected.push({ guid: guid, role: inferGuidRoleFromKey(keyHint) });
    }

    Object.keys(flat).forEach(function (key) {
      collectFromValue(flat[key], key);
    });

    collected.forEach(function (entry) {
      if (entry.role === "object" && !ids.objectId) ids.objectId = entry.guid;
      else if (entry.role === "record" && !ids.recordId) ids.recordId = entry.guid;
      else if (entry.role === "instance" && !ids.instanceId) ids.instanceId = entry.guid;
    });

    var unknownGuids = collected
      .filter(function (entry) {
        return (
          entry.role === "unknown" &&
          entry.guid !== ids.objectId &&
          entry.guid !== ids.recordId &&
          entry.guid !== ids.instanceId
        );
      })
      .map(function (entry) {
        return entry.guid;
      });

    if (!ids.recordId && unknownGuids.length) ids.recordId = unknownGuids[0];
    if (!ids.instanceId && unknownGuids.length > 1) ids.instanceId = unknownGuids[1];
    if (!ids.objectId && unknownGuids.length > 2) ids.objectId = unknownGuids[2];

    if (!ids.recordId && ids.instanceId) ids.recordId = ids.instanceId;
    if (!ids.instanceId && ids.recordId) ids.instanceId = ids.recordId;

    return ids;
  }

  function buildTicketDetailUrlParts(objectId, recordId, instanceId) {
    var rid = extractRecordGuid(recordId);
    if (!rid) return "";

    var params = new URLSearchParams({
      rn: "ehd",
      oid: extractRecordGuid(objectId) || "",
      rid: rid,
      incid: extractRecordGuid(instanceId) || "",
      redirectFrom: "helpdesk-my-ticket",
    });
    // Root-relative on purpose: no base URL is prepended, so the link always
    // resolves against whatever origin the page is actually served from.
    // The old "!base" guard went with it - the link no longer depends on the
    // base being resolvable, so a missing one must not suppress it.
    return "/workflow-engine/request-details?" + params.toString();
  }

  function normalizeCategoryRows(payload) {
    var rows = extractRows(payload);
    return rows.map(function (row) {
      if (!row || typeof row !== "object") return row;
      var out = Object.assign({}, row);
      var rfv = Array.isArray(row.RecordFieldValues) ? row.RecordFieldValues : [];
      rfv.forEach(function (item) {
        var key = toSafeString(
          item.FieldInternalName || item.FieldName || item.DisplayName || item.name
        );
        if (!key) return;
        var val =
          item.UGFieldValue != null
            ? item.UGFieldValue
            : item.FieldValue != null
              ? item.FieldValue
              : item.Value;
        if (out[key] == null || out[key] === "") out[key] = val;
      });
      return out;
    });
  }

  function pickField(row, keys) {
    if (!row || typeof row !== "object") return "";
    for (var i = 0; i < keys.length; i += 1) {
      var val = row[keys[i]];
      if (val != null && String(val).trim() !== "") return String(val).trim();
    }
    return "";
  }

  function isPermissionRestrictedAppTitle(appTitle) {
    return Boolean(matchesDashboardApp(appTitle));
  }

  function resolveAppTitleForRequestType(requestType) {
    var type = toSafeString(requestType);
    if (!type) return "";

    var matcherKey = "";
    var index;
    for (index = 0; index < DASHBOARD_APP_MATCHERS.length; index += 1) {
      if (DASHBOARD_APP_MATCHERS[index].label === type) {
        matcherKey = DASHBOARD_APP_MATCHERS[index].key;
        break;
      }
    }
    if (!matcherKey) return "";

    var configs = Array.isArray(state.workflowConfigs) ? state.workflowConfigs : [];
    for (index = 0; index < configs.length; index += 1) {
      if (getDashboardAppMatchKey(configs[index]) === matcherKey) {
        return toSafeString(configs[index].appTitle);
      }
    }
    return "";
  }

  function isRestrictedTicketFormVisible(row, newLP, employeeGuid) {
    if (hasUnrestrictedTicketAccess(newLP)) return true;

    var permissions = parseAppPermissions(
      pickField(row, ["AppPermissions", "appPermissions"])
    );
    if (!permissions.length) return false;

    var guid = toSafeString(employeeGuid).toLowerCase();
    var index;
    for (index = 0; index < permissions.length; index += 1) {
      var perm = permissions[index];
      if (!perm || typeof perm !== "object") continue;
      var userId = toSafeString(perm.UserID || perm.userId || perm.userID);
      if (!userId) continue;
      if (userId.toUpperCase() === "ALL") return true;
      if (guid && userId.toLowerCase() === guid) return true;
    }
    return false;
  }

  function shouldShowWorkflowRow(row, newLP, employeeGuid) {
    var appTitle = pickField(row, ["AppTitle", "appTitle", "Title", "WFName", "WfName"]);
    if (!isPermissionRestrictedAppTitle(appTitle)) return true;
    return isRestrictedTicketFormVisible(row, newLP, employeeGuid);
  }

  function filterRowsByAppPermissions(rows, newLP, employeeGuid) {
    return (Array.isArray(rows) ? rows : []).filter(function (row) {
      return shouldShowWorkflowRow(row, newLP, employeeGuid);
    });
  }

  var ALLOWED_OBJECT_NAMES = [
    "IT_Incident_Request",
    "IT_Problem_Request",
    "IT_Service_Request",
    "IT_Change_Request",
  ];
  var REQUIRED_TRIGGERD_ON = "ON_ADDED";

  function isShowInAppsEnabled(row) {
    return isTruthyDisabled(pickField(row, ["ShowInApps", "showInApps"]));
  }

  function isAllowedObjectName(row) {
    var objectName = pickField(row, ["ObjectName", "objectName"]);
    return ALLOWED_OBJECT_NAMES.indexOf(objectName) >= 0;
  }

  function isRequiredTriggerdOn(row) {
    var triggerdOn = pickField(row, ["TriggerdOn", "TriggeredOn", "triggerdOn", "triggeredOn"]);
    return triggerdOn === REQUIRED_TRIGGERD_ON;
  }

  // Admin-configured conditions: the same for every viewer of a given
  // WorkflowConfigList row. AppPermissions is intentionally NOT included
  // here -- it is per-user and is enforced separately in
  // isRestrictedTicketFormVisible so it can never be short-circuited.
  function passesDashboardConfigConditions(row) {
    return (
      isShowInAppsEnabled(row) &&
      isAllowedObjectName(row) &&
      isRequiredTriggerdOn(row)
    );
  }

  // All four conditions must be satisfied together for a row to be shown:
  // AppPermissions, ShowInApps, ObjectName (allow-list), and TriggerdOn (ON_ADDED).
  // AppPermissions is checked directly (isRestrictedTicketFormVisible) rather
  // than through the app-title gate, so permissions are always evaluated --
  // matching the reference isTicketFormVisible behavior in service.js -- and
  // a row is never shown to a user who isn't listed in AppPermissions just
  // because its title didn't match a known dashboard app pattern.
  function passesDashboardVisibility(row, newLP, employeeGuid) {
    return (
      isRestrictedTicketFormVisible(row, newLP, employeeGuid) &&
      passesDashboardConfigConditions(row)
    );
  }

  function filterRowsByDashboardVisibility(rows, newLP, employeeGuid) {
    return (Array.isArray(rows) ? rows : []).filter(function (row) {
      return passesDashboardVisibility(row, newLP, employeeGuid);
    });
  }

  function isGuid(value) {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
      toSafeString(value)
    );
  }

  /** For link params: use GUID from lookup (`id;#Label`) or plain UUID string. */
  function extractRecordGuid(value) {
    if (value == null || value === "") return "";
    if (typeof value === "object") {
      return extractRecordGuid(
        value.RecordID ||
          value.RecordId ||
          value.ID ||
          value.Id ||
          value.id ||
          value.GUID ||
          value.guid ||
          value.InstanceID ||
          value.ObjectID
      );
    }
    var text = toSafeString(value);
    if (!text) return "";
    if (text.indexOf(";#") >= 0) {
      var parts = text.split(";#");
      var left = toSafeString(parts[0]);
      if (isGuid(left)) return left;
      for (var i = 1; i < parts.length; i += 1) {
        var part = toSafeString(parts[i]);
        if (isGuid(part)) return part;
      }
    }
    if (isGuid(text)) return text;
    var match = text.match(
      /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i
    );
    return match ? match[0] : "";
  }

  function pickLinkField(row, keys) {
    var direct = extractRecordGuid(pickField(row, keys));
    if (direct) return direct;
    if (!row || typeof row !== "object") return "";

    var hints = keys.map(function (key) {
      return String(key || "")
        .replace(/[^a-z0-9]/gi, "")
        .toLowerCase();
    });

    for (var prop in row) {
      if (!Object.prototype.hasOwnProperty.call(row, prop)) continue;
      var norm = String(prop || "")
        .replace(/[^a-z0-9]/gi, "")
        .toLowerCase();
      for (var i = 0; i < hints.length; i += 1) {
        if (!hints[i]) continue;
        if (norm === hints[i] || norm.indexOf(hints[i]) >= 0 || hints[i].indexOf(norm) >= 0) {
          var guid = extractRecordGuid(row[prop]);
          if (guid) return guid;
        }
      }
    }
    return "";
  }

  function resolveWorkflowObjectId(ticket) {
    var configs = Array.isArray(state.workflowConfigs) ? state.workflowConfigs : [];
    if (!configs.length || !ticket) return "";

    var type = toSafeString(ticket.requestType).toLowerCase();
    var title = toSafeString(ticket.requestTitle).toLowerCase();
    var ticketId = toSafeString(ticket.ticketId).toLowerCase();

    function matchesConfig(app) {
      var wfName = toSafeString(app.wfName || app.appTitle).toLowerCase();
      var objectName = toSafeString(app.objectName).toLowerCase();
      if (!type && !title && !ticketId) return false;
      if (type && wfName.indexOf(type.replace(" request", "")) >= 0) return true;
      if (type && objectName.indexOf(type.replace(/\s+/g, "_").replace(" request", "")) >= 0)
        return true;
      if (title && wfName && (title.indexOf(wfName) >= 0 || wfName.indexOf(title) >= 0))
        return true;
      if (ticketId) {
        if (ticketId.indexOf("cr") === 0 && wfName.indexOf("change") >= 0) return true;
        if (ticketId.indexOf("sr") === 0 && wfName.indexOf("service") >= 0) return true;
        if (ticketId.indexOf("pr") === 0 || ticketId.indexOf("rp") === 0) {
          if (wfName.indexOf("problem") >= 0 || wfName.indexOf("report") >= 0) return true;
        }
        if (ticketId.indexOf("ir") === 0 && wfName.indexOf("incident") >= 0) return true;
      }
      return false;
    }

    for (var i = 0; i < configs.length; i += 1) {
      if (!matchesConfig(configs[i])) continue;
      var objectId = extractRecordGuid(configs[i].objectId);
      if (objectId) return objectId;
    }
    return "";
  }

  function lookupToText(value) {
    if (window.QafLibrary && typeof window.QafLibrary.lookupToText === "function") {
      return window.QafLibrary.lookupToText(value, "");
    }
    if (value == null) return "";
    if (typeof value === "string") {
      var text = value.trim();
      if (!text) return "";
      if (text.indexOf(";#") >= 0) {
        var parts = text.split(";#");
        return toSafeString(parts[parts.length - 1]) || text;
      }
      return text;
    }
    if (typeof value === "number" || typeof value === "boolean") return String(value);
    if (Array.isArray(value)) {
      return value
        .map(function (item) {
          return lookupToText(item, "");
        })
        .filter(Boolean)
        .join(", ");
    }
    if (typeof value === "object") {
      var candidate =
        value.DisplayName ||
        value.Name ||
        value.label ||
        value.value ||
        value.Title ||
        value.text;
      if (candidate != null) return lookupToText(candidate, "");
      if (value.RecordID) return lookupToText(value.RecordID, "");
    }
    return "";
  }

  function normalizeRequesterValue(value) {
    if (value == null || value === "") return "";
    if (typeof value === "object") {
      return lookupToText(
        value.DisplayName ||
          value.Name ||
          value.UserName ||
          value.Email ||
          value.RecordID,
        ""
      );
    }
    var text = toSafeString(value);
    if (!text) return "";
    if (text.charAt(0) === "[" || text.charAt(0) === "{") {
      var parsed = tryParseJson(text);
      if (parsed) {
        if (Array.isArray(parsed) && parsed.length) {
          return normalizeRequesterValue(parsed[0]);
        }
        if (typeof parsed === "object") {
          return lookupToText(
            parsed.DisplayName ||
              parsed.Name ||
              parsed.UserName ||
              parsed.Email ||
              parsed.RecordID,
            lookupToText(parsed, "")
          );
        }
      }
    }
    return lookupToText(text, text);
  }

  function isTruthyDisabled(value) {
    if (value === true || value === 1) return true;
    var text = String(value == null ? "" : value).trim().toLowerCase();
    return text === "true" || text === "1" || text === "yes";
  }

  function buildAppIconSrc(appIconValue) {
    var appIcon = toSafeString(appIconValue);
    if (!appIcon) return DEFAULT_APP_ICON;
    return "/Attachment/downloadfile?fileUrl=" + encodeURIComponent(appIcon);
  }

  function normalizeWorkflowApps(rows) {
    return (Array.isArray(rows) ? rows : [])
      .filter(function (row) {
        return row && !isTruthyDisabled(pickField(row, ["IsDisabled", "isDisabled"]));
      })
      .map(function (row, index) {
        return {
          id: pickField(row, ["WFID", "WfId", "wfId", "Id", "ID"]) || "app-" + index,
          appIcon: buildAppIconSrc(pickField(row, ["AppIcon", "appIcon"])),
          appTitle: pickField(row, ["AppTitle", "appTitle", "Title", "WFName", "WfName"]),
          appDescription: pickField(row, [
            "AppDescription",
            "appDescription",
            "Description",
          ]),
          wfId: pickField(row, ["WFID", "WfId", "wfId"]),
          wfName: pickField(row, ["WFName", "WfName", "wfName"]),
          objectName: pickField(row, ["ObjectName", "objectName"]),
          objectId: pickField(row, ["ObjectID", "ObjectId", "objectId"]),
          _sourceRow: row,
        };
      })
      .filter(function (app) {
        return Boolean(app.appTitle);
      });
  }

  function matchesDashboardApp(title) {
    var normalized = toSafeString(title).toLowerCase();
    if (!normalized) return "";
    for (var i = 0; i < DASHBOARD_APP_MATCHERS.length; i += 1) {
      var matcher = DASHBOARD_APP_MATCHERS[i];
      for (var p = 0; p < matcher.patterns.length; p += 1) {
        if (normalized.indexOf(matcher.patterns[p]) >= 0) return matcher.key;
      }
    }
    return "";
  }

  function getDashboardAppMatchKey(app) {
    if (!app) return "";
    var fields = [app.appTitle, app.wfName, app.objectName];
    var index;
    for (index = 0; index < fields.length; index += 1) {
      var key = matchesDashboardApp(fields[index]);
      if (key) return key;
    }
    return "";
  }

  /* ======================================================================
   * DATE / TIME ENGINE
   * ----------------------------------------------------------------------
   * Contract:
   *   - Every DateTime returned by the API is UTC.
   *   - The display offset comes from LocalStorage CS_SETTING.TimeZone, e.g.
   *     "0d87b7dc-...;#(UTC+5:30) Chennai, Kolkata, Mumbai, New Delhi".
   *     Only the "(UTC+5:30)" part is read; the GUID and city names are ignored.
   *   - The clock style comes from LocalStorage TimeFormat ("12 Hour"/"24 Hour").
   *   - Output is DD/MM/YYYY, with hh:mm:ss AM/PM (12 Hour) or HH:mm:ss (24 Hour).
   * No timezone is hardcoded anywhere below.
   * ==================================================================== */

  // Used only when TimeFormat is absent or unreadable in LocalStorage.
  var DEFAULT_TIME_FORMAT_IS_24_HOUR = true;

  var userDateSettingsCache = null;

  function pad2(n) {
    return String(n).length < 2 ? "0" + n : String(n);
  }

  function readLocalStorageValue(key) {
    try {
      if (!window.localStorage) return "";
      var value = window.localStorage.getItem(key);
      return value == null ? "" : String(value);
    } catch (_) {
      return "";
    }
  }

  function stripWrappingQuotes(value) {
    return String(value == null ? "" : value)
      .trim()
      .replace(/^['"]+|['"]+$/g, "")
      .trim();
  }

  /**
   * Extracts the UTC offset from a timezone setting string.
   * Accepts "(UTC+5:30)", "(UTC+05:30)", "(UTC-8:00)", "(GMT+10:30)", "(UTC)".
   * Returns the offset in minutes, or null when none is present.
   */
  function parseUtcOffsetMinutes(rawTimeZone) {
    var text = stripWrappingQuotes(rawTimeZone);
    if (!text) return null;
    var match = /\(\s*(?:UTC|GMT)\s*([+-])\s*(\d{1,2})\s*(?:[:.]\s*(\d{1,2}))?\s*\)/i.exec(text);
    if (match) {
      var sign = match[1] === "-" ? -1 : 1;
      var hours = Number(match[2]) || 0;
      var minutes = match[3] != null ? Number(match[3]) || 0 : 0;
      var total = sign * (hours * 60 + minutes);
      return isFinite(total) ? total : null;
    }
    // "(UTC)" / "(GMT)" with no signed offset means zero.
    if (/\(\s*(?:UTC|GMT)\s*\)/i.test(text)) return 0;
    return null;
  }

  /**
   * CS_SETTING may be plain JSON, a JSON string inside a JSON string, or
   * wrapped in a { value: ... } envelope. Returns every object worth checking.
   */
  function getCsSettingObjects() {
    var objects = [];
    try {
      var parsed = tryParseJson(readLocalStorageValue("CS_SETTING") || "");
      if (typeof parsed === "string") parsed = tryParseJson(parsed);
      if (parsed && typeof parsed === "object") {
        objects.push(parsed);
        if (typeof parsed.value === "string") {
          var inner = tryParseJson(parsed.value);
          if (inner && typeof inner === "object") objects.push(inner);
        } else if (parsed.value && typeof parsed.value === "object") {
          objects.push(parsed.value);
        }
      }
    } catch (_) {
      // Ignore storage / parse issues and fall back to defaults.
    }
    return objects;
  }

  function pickCsSettingField(objects, names) {
    var i;
    var n;
    for (i = 0; i < objects.length; i += 1) {
      var source = objects[i];
      if (!source || typeof source !== "object") continue;
      for (n = 0; n < names.length; n += 1) {
        var value = source[names[n]];
        if (value != null && String(value).trim() !== "") return String(value);
      }
    }
    return "";
  }

  /** Reads (and memoises) the user's timezone offset and clock style. */
  function getUserDateSettings() {
    if (userDateSettingsCache) return userDateSettingsCache;

    var csObjects = getCsSettingObjects();

    var offsetMinutes = parseUtcOffsetMinutes(
      pickCsSettingField(csObjects, ["TimeZone", "timeZone", "Timezone", "timezone"])
    );
    // Fallbacks: raw CS_SETTING text (when it is not valid JSON), then a
    // standalone TimeZone key if the host app writes one.
    if (offsetMinutes == null) offsetMinutes = parseUtcOffsetMinutes(readLocalStorageValue("CS_SETTING"));
    if (offsetMinutes == null) offsetMinutes = parseUtcOffsetMinutes(readLocalStorageValue("TimeZone"));
    if (offsetMinutes == null) offsetMinutes = 0; // Nothing configured -> show UTC as-is.

    var timeFormatRaw = stripWrappingQuotes(readLocalStorageValue("TimeFormat"));
    if (!timeFormatRaw) {
      timeFormatRaw = stripWrappingQuotes(pickCsSettingField(csObjects, ["TimeFormat", "timeFormat"]));
    }
    var is24Hour = timeFormatRaw ? /24/.test(timeFormatRaw) : DEFAULT_TIME_FORMAT_IS_24_HOUR;

    userDateSettingsCache = { offsetMinutes: offsetMinutes, is24Hour: is24Hour };
    return userDateSettingsCache;
  }

  /** Drops the memoised settings so the next render re-reads LocalStorage. */
  function invalidateUserDateSettings() {
    userDateSettingsCache = null;
  }

  try {
    // Fires when another tab changes the settings.
    window.addEventListener("storage", function (event) {
      var key = event && event.key;
      if (!key || key === "CS_SETTING" || key === "TimeFormat" || key === "TimeZone") {
        invalidateUserDateSettings();
      }
    });
    // The "storage" event only fires for OTHER tabs. If the user can change
    // these settings in THIS tab, call this hook and then re-render.
    window.ServiceDashboard = window.ServiceDashboard || {};
    window.ServiceDashboard.refreshDateSettings = invalidateUserDateSettings;
  } catch (_) {
    // Ignore environments without window events / writable globals.
  }

  /**
   * Parses a DateTime into the UTC instant it represents.
   * Supported inputs:
   *   - "M/D/YYYY h:mm:ss AM/PM"  month-first, e.g. "7/28/2026 5:14:39 AM"
   *   - "YYYY-MM-DDTHH:mm:ss"     no zone suffix -> treated as UTC
   *   - ISO strings with "Z" or an explicit +HH:mm / -HH:mm offset
   *   - "/Date(1690000000000)/"   .NET serialised dates
   *   - "DD/MM/YYYY HH:mm:ss"     display strings produced by this page
   *   - Date objects and epoch numbers
   * Returns { date: Date, hasTime: boolean } or null.
   */
  function parseApiDateValue(input) {
    // Shared, reusable implementation now lives in library.js
    // (QafLibrary.parseApiDateValue) so the Team Dashboard grid can use the
    // exact same date parsing/disambiguation. This wrapper is kept so every
    // existing call site below (getUserZoneParts, getDateSortValue, etc.)
    // stays unchanged.
    if (window.QafLibrary && typeof window.QafLibrary.parseApiDateValue === "function") {
      return window.QafLibrary.parseApiDateValue(input);
    }

    if (input == null || input === "") return null;

    if (input instanceof Date) {
      return isFinite(input.getTime()) ? { date: input, hasTime: true } : null;
    }
    if (typeof input === "number" && isFinite(input)) {
      var fromEpoch = new Date(input);
      return isFinite(fromEpoch.getTime()) ? { date: fromEpoch, hasTime: true } : null;
    }

    var text = String(input).trim();
    if (!text) return null;

    // .NET: /Date(1690000000000)/ or /Date(1690000000000+0530)/
    var dotNet = /^\/Date\((-?\d+)(?:[+-]\d{4})?\)\/$/.exec(text);
    if (dotNet) {
      var fromTicks = new Date(Number(dotNet[1]));
      return isFinite(fromTicks.getTime()) ? { date: fromTicks, hasTime: true } : null;
    }

    // ISO-8601: 2026-07-28T05:24:37 (bare = UTC), optionally with Z or an offset.
    var iso = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s](\d{1,2}):(\d{2})(?::(\d{2}))?(?:\.(\d{1,7}))?)?\s*(Z|[+-]\d{2}:?\d{2})?$/i.exec(
      text
    );
    if (iso) {
      var isoHasTime = iso[4] != null;
      var zone = iso[8] || "";
      if (zone) {
        // An explicit zone is authoritative; let the engine resolve it.
        var zoned = new Date(text.replace(" ", "T"));
        return isFinite(zoned.getTime()) ? { date: zoned, hasTime: isoHasTime } : null;
      }
      var millisText = iso[7] != null ? String(iso[7]).slice(0, 3) : "";
      while (millisText.length && millisText.length < 3) millisText += "0";
      var isoUtc = new Date(
        Date.UTC(
          Number(iso[1]),
          Number(iso[2]) - 1,
          Number(iso[3]),
          isoHasTime ? Number(iso[4]) : 0,
          iso[5] != null ? Number(iso[5]) : 0,
          iso[6] != null ? Number(iso[6]) : 0,
          millisText ? Number(millisText) : 0
        )
      );
      return isFinite(isoUtc.getTime()) ? { date: isoUtc, hasTime: isoHasTime } : null;
    }

    // Slash format, with or without a time part and AM/PM suffix.
    var slash = /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[\s,]+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?\s*(?:([AaPp])\.?[Mm]\.?)?)?$/.exec(
      text
    );
    if (slash) {
      var first = Number(slash[1]);
      var second = Number(slash[2]);
      var year = Number(slash[3]);

      // The API sends month-first (MM/DD/YYYY). A first component above 12 can
      // only be a day, which also lets this page's own DD/MM/YYYY output
      // round-trip correctly if it is ever re-parsed.
      var monthFirst = !(first > 12 && second <= 12);
      var month = monthFirst ? first : second;
      var day = monthFirst ? second : first;
      if (month < 1 || month > 12 || day < 1 || day > 31) return null;

      var slashHasTime = slash[4] != null;
      var hours = slashHasTime ? Number(slash[4]) : 0;
      var minutes = slash[5] != null ? Number(slash[5]) : 0;
      var seconds = slash[6] != null ? Number(slash[6]) : 0;
      var meridiem = slash[7] ? slash[7].toLowerCase() : "";
      if (meridiem === "p" && hours < 12) hours += 12;
      if (meridiem === "a" && hours === 12) hours = 0;

      var slashUtc = new Date(Date.UTC(year, month - 1, day, hours, minutes, seconds));
      if (!isFinite(slashUtc.getTime())) return null;
      // Reject impossible calendar dates such as 31/02/2026.
      if (slashUtc.getUTCMonth() !== month - 1 || slashUtc.getUTCDate() !== day) return null;
      return { date: slashUtc, hasTime: slashHasTime };
    }

    var fallback = new Date(text);
    return isFinite(fallback.getTime()) ? { date: fallback, hasTime: true } : null;
  }

  /**
   * Converts a parsed UTC value into the calendar/clock parts to display.
   * applyOffset is false for date-only rendering, where shifting the instant
   * could roll the calendar date onto the previous or next day.
   */
  function getUserZoneParts(value, applyOffset) {
    var parsed = parseApiDateValue(value);
    if (!parsed) return null;
    // A value carrying no time component has no instant to shift.
    var shiftMinutes = applyOffset && parsed.hasTime ? getUserDateSettings().offsetMinutes : 0;
    var shifted = new Date(parsed.date.getTime() + shiftMinutes * 60000);
    if (!isFinite(shifted.getTime())) return null;
    return {
      day: shifted.getUTCDate(),
      month: shifted.getUTCMonth() + 1,
      year: shifted.getUTCFullYear(),
      hours: shifted.getUTCHours(),
      minutes: shifted.getUTCMinutes(),
      seconds: shifted.getUTCSeconds(),
      hasTime: parsed.hasTime
    };
  }

  /**
   * Date-only output: DD/MM/YYYY.
   * The offset is deliberately not applied, so a calendar date can never roll
   * to the previous or next day for users on negative or large offsets.
   */
  function formatUserDate(value) {
    var parts = getUserZoneParts(value, false);
    if (!parts) return "";
    return pad2(parts.day) + "/" + pad2(parts.month) + "/" + parts.year;
  }

  /**
   * DateTime output, converted from UTC to the user's offset:
   *   12 Hour -> DD/MM/YYYY hh:mm:ss AM/PM
   *   24 Hour -> DD/MM/YYYY HH:mm:ss
   */
  function formatUserDateTime(value, includeSeconds) {
    var parts = getUserZoneParts(value, true);
    if (!parts) return "";
    var withSeconds = includeSeconds !== false;
    var datePart = pad2(parts.day) + "/" + pad2(parts.month) + "/" + parts.year;
    var secondsPart = withSeconds ? ":" + pad2(parts.seconds) : "";

    if (getUserDateSettings().is24Hour) {
      return datePart + " " + pad2(parts.hours) + ":" + pad2(parts.minutes) + secondsPart;
    }

    var meridiem = parts.hours >= 12 ? "PM" : "AM";
    var hour12 = parts.hours % 12 === 0 ? 12 : parts.hours % 12;
    return datePart + " " + pad2(hour12) + ":" + pad2(parts.minutes) + secondsPart + " " + meridiem;
  }

  /**
   * Display entry point for grid cells. Falls back to the raw text when the
   * value cannot be parsed, so nothing is silently blanked out.
   */
  function formatDisplayDateTime(value) {
    if (value == null || value === "") return "";
    return formatUserDateTime(value, true) || lookupToText(value, "");
  }

  /** UTC epoch for a value, for sorting. Returns null when unparseable. */
  function getDateSortValue(value) {
    var parsed = parseApiDateValue(value);
    if (!parsed) return null;
    var time = parsed.date.getTime();
    return isFinite(time) ? time : null;
  }

  function normalizeTicketRow(row) {
    if (!row || typeof row !== "object") return null;

    var flat = flattenTicketSourceRow(row);
    var linkIds = resolveTicketLinkIds(flat);

    var statusRaw = pickField(flat, ["Status", "RequestStatus", "status"]);
    var requesterRaw = pickField(flat, ["Requester"]);
    var openedByRaw = pickField(flat, ["CreatedByName"]);

    return {
      ticketId: lookupToText(pickField(flat, ["TicketID", "TicketId", "ticketId"]), ""),
      requestTitle: lookupToText(
        pickField(flat, ["RequestTitle", "Title", "Subject"]),
        ""
      ),
      ticketType: lookupToText(pickField(flat, ["RequestType", "requestType"]), ""),
      customer: lookupToText(pickField(flat, ["Customer", "customer"]), ""),
      requester: normalizeRequesterValue(requesterRaw),
      priority: lookupToText(pickField(flat, ["Priority", "priority"]), ""),
      dueDate: formatDisplayDateTime(pickField(flat, ["DueDate", "Due Date", "dueDate"])),
      // UTC epoch kept alongside the display string so the grid can sort on the
      // real instant instead of on "01:00:00 PM" vs "10:00:00 AM" text order.
      dueDateSort: getDateSortValue(pickField(flat, ["DueDate", "Due Date", "dueDate"])),
      assignedTo: lookupToText(pickField(flat, ["AssignedTo", "Assigned To"]), ""),
      createdDate: formatDisplayDateTime(
        pickField(flat, ["CreatedDate", "Created Date", "createdDate"])
      ),
      createdDateSort: getDateSortValue(
        pickField(flat, ["CreatedDate", "Created Date", "createdDate"])
      ),
      openedBy: lookupToText(openedByRaw, ""),
      status: lookupToText(statusRaw, ""),
      statusRaw: statusRaw,
      assignedTeam: lookupToText(
        pickField(flat, ["PendingWithTeamName", "AssignedToTeam", "Assigned To Team"]),
        ""
      ),
      requestType: resolveTicketRequestType(flat),
      objectId: linkIds.objectId,
      recordId: linkIds.recordId,
      instanceId: linkIds.instanceId,
      linkIds: linkIds,
      createdByGuid: pickField(flat, ["CreatedByGUID", "CreatedByGuid", "createdByGUID"]),
      _sourceRow: flat,
      _searchText: "",
    };
  }

  function resolveTicketRequestType(flat) {
    if (!flat || typeof flat !== "object") return "";
    var raw = pickField(flat, [
      "RequestType",
      "requestType",
      "Type",
      "WFName",
      "WfName",
      "wfName",
      "AppTitle",
      "appTitle",
    ]);
    var text = lookupToText(raw, "");
    if (!text || isGuid(text)) {
      var fallback = lookupToText(
        pickField(flat, ["WFName", "WfName", "wfName", "AppTitle", "appTitle", "Title"]),
        ""
      );
      if (fallback && !isGuid(fallback)) return fallback;
      return isGuid(text) ? "" : text;
    }
    return text;
  }

  function buildTicketSearchText(ticket) {
    return TABLE_COLUMNS.map(function (col) {
      return toSafeString(ticket[col.key]);
    })
      .concat([toSafeString(ticket.requestType)])
      .join(" ")
      .toLowerCase();
  }

  function normalizeMyServicesRows(payload) {
    var employeeGuid = getEmployeeGuid();
    return extractRows(payload)
      .map(normalizeTicketRow)
      .filter(function (ticket) {
        if (!ticket || !ticket.ticketId) return false;
        if (!employeeGuid) return true;
        var createdBy = toSafeString(ticket.createdByGuid).toLowerCase();
        return !createdBy || createdBy === employeeGuid.toLowerCase();
      })
      .map(function (ticket) {
        ticket._searchText = buildTicketSearchText(ticket);
        return ticket;
      });
  }

  function fetchWorkflowConfigListOnce() {
    if (workflowConfigPromise) return workflowConfigPromise;

    workflowConfigPromise = (async function () {
      var base = getApiBaseUrl();
      var url =
        base +
        "/api/WorkflowConfigList?templateType=" +
        encodeURIComponent(WORKFLOW_TEMPLATE);
      var response = await fetch(url, {
        method: "GET",
        headers: getAuthHeaders(),
      });
      if (!response.ok) {
        throw new Error(
          "WorkflowConfigList failed (" + response.status + " " + response.statusText + ")"
        );
      }
      var payload = await response.json();
      if (payload === false) return [];
      var rows = extractRows(payload);
      return normalizeWorkflowApps(rows);
    })().catch(function (error) {
      workflowConfigPromise = null;
      throw error;
    });

    return workflowConfigPromise;
  }

  function fetchStatusOptionsOnce() {
    if (statusRowsPromise) return statusRowsPromise;

    statusRowsPromise = (async function () {
      var qafService = getQafService();
      if (!qafService || typeof qafService.GetItems !== "function") {
        throw new Error("QafService.GetItems is not available.");
      }
      var response = await qafService.GetItems(
        STATUS_REPOSITORY,
        STATUS_FIELDS,
        10000,
        1,
        "",
        "StatusName",
        true
      );
      var rows = normalizeCategoryRows(response);
      return rows
        .map(function (row) {
          return {
            recordId: pickField(row, ["RecordID", "RecordId", "recordId", "ID", "Id"]),
            statusName: pickField(row, ["StatusName", "statusName", "Name"]),
          };
        })
        .filter(function (item) {
          return Boolean(item.statusName);
        });
    })().catch(function (error) {
      statusRowsPromise = null;
      throw error;
    });

    return statusRowsPromise;
  }

  async function postApiJson(url, body) {
    var response = await fetch(url, {
      method: "POST",
      headers: getAuthHeaders(),
      body: body == null ? "{}" : typeof body === "string" ? body : JSON.stringify(body),
    });
    if (!response.ok) {
      throw new Error("API request failed (" + response.status + ") for " + url);
    }
    var text = await response.text();
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch (_) {
      return text;
    }
  }

  function extractWorkflowNames(payload) {
    var seen = {};
    var names = [];
    extractRows(payload).forEach(function (row) {
      var wfName = pickField(row, ["WFName", "wfname", "WFNAME", "WfName", "WF Name"]);
      if (!wfName) return;
      var key = wfName.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      names.push(wfName);
    });
    return names;
  }

  function loadRequestTypeOptions() {
    if (state.typeOptionsLoaded) {
      return Promise.resolve(state.typeOptions.slice());
    }
    if (typeOptionsPromise) return typeOptionsPromise;

    typeOptionsPromise = (async function () {
      var base = getApiBaseUrl();
      if (!base) throw new Error("API base URL is missing.");
      var payload = await postApiJson(base + "/api/rnsp", {
        Name: REQUEST_TYPE_WF_PROCEDURE,
        Args: {},
      });
      state.typeOptions = extractWorkflowNames(payload);
      state.typeOptionsLoaded = true;
      typeOptionsPromise = null;
      return state.typeOptions.slice();
    })().catch(function () {
      state.typeOptions = [];
      state.typeOptionsLoaded = true;
      typeOptionsPromise = null;
      return [];
    });

    return typeOptionsPromise;
  }

  function buildSearchWhereClause(query) {
    var q = toSafeString(query);
    if (!q) return "";
    var escaped = q.replace(/'/g, "''");
    var fields = [
      "TicketID",
      "RequestTitle",
      "RequestFor",
      "Priority",
      "AssignedTo",
      "Status",
      "RequestStatus",
      "PendingWithTeamName",
      "RequestType",
    ];
    return fields
      .map(function (field) {
        return field + "<contains>'" + escaped + "'";
      })
      .join("<OR>");
  }

  function buildStatusWhereClause(statusOption) {
    if (!statusOption) return "";
    var name = toSafeString(statusOption.statusName);
    var recordId = toSafeString(statusOption.recordId);
    if (!name && !recordId) return "";
    var parts = [];
    if (name) {
      parts.push("Status='ExactValue'<OR>RequestStatus<contains>'" + name.replace(/'/g, "''") + "'");
      parts.push("Status<contains>'" + name.replace(/'/g, "''") + "'");
    }
    if (recordId) {
      parts.push("RequestStatus<contains>'" + recordId.replace(/'/g, "''") + ";#");
    }
    return parts.join("<OR>");
  }

  function getRequestTypeFilterTerms(requestType) {
    var type = toSafeString(requestType);
    if (!type) return [];
    return REQUEST_TYPE_FILTERS[type] || [type];
  }

  function getRequestTypeTicketPrefixes(requestType) {
    var type = toSafeString(requestType);
    if (!type) return [];
    return REQUEST_TYPE_TICKET_PREFIXES[type] || [];
  }

  function ticketIdMatchesRequestTypePrefix(ticketId, requestType) {
    var prefixes = getRequestTypeTicketPrefixes(requestType);
    var id = toSafeString(ticketId).toUpperCase();
    if (!id || !prefixes.length) return false;
    for (var i = 0; i < prefixes.length; i += 1) {
      if (id.indexOf(toSafeString(prefixes[i]).toUpperCase()) === 0) return true;
    }
    return false;
  }

  function buildRequestTypeWhereClause(requestType) {
    var type = toSafeString(requestType);
    if (!type) return "";
    var terms = getRequestTypeFilterTerms(type);
    var prefixes = getRequestTypeTicketPrefixes(type);
    var seen = {};
    var parts = [];
    terms.forEach(function (term) {
      var key = term.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      parts.push("RequestType<contains>'" + term.replace(/'/g, "''") + "'");
    });
    prefixes.forEach(function (prefix) {
      var key = "ticket:" + prefix.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      parts.push("TicketID<contains>'" + prefix.replace(/'/g, "''") + "'");
    });
    return parts.join("<OR>");
  }

  function buildMyServicesUrl(options) {
    var config = options || {};
    var base = getApiBaseUrl();
    var params = new URLSearchParams({
      option: "MS",
      app: "helpdesk",
      templateType: WORKFLOW_TEMPLATE,
    });
    var whereParts = [];
    var statusClause = buildStatusWhereClause(
      config.statusRecordId || config.statusName
        ? {
            statusName: config.statusName,
            recordId: config.statusRecordId,
          }
        : null
    );
    if (statusClause) whereParts.push(statusClause);
    var requestTypeClause = buildRequestTypeWhereClause(config.requestType);
    if (requestTypeClause) whereParts.push(requestTypeClause);
    var searchClause = buildSearchWhereClause(config.searchQuery);
    if (searchClause) whereParts.push(searchClause);
    if (whereParts.length) {
      params.set("whereClause", whereParts.join("<<NG>>"));
    }
    return base + "/api/MyServices?" + params.toString();
  }

  async function fetchMyServices(options) {
    var url = buildMyServicesUrl(options || {});
    var response = await fetch(url, {
      method: "GET",
      headers: getAuthHeaders(),
    });
    if (!response.ok) {
      throw new Error(
        "MyServices failed (" + response.status + " " + response.statusText + ")"
      );
    }
    var payload = await response.json();
    if (payload === false) return [];
    return normalizeMyServicesRows(payload);
  }

  function requestTypeMatches(ticket, requestTypeFilter) {
    var filter = toSafeString(requestTypeFilter);
    if (!filter) return true;
    if (ticketIdMatchesRequestTypePrefix(ticket.ticketId, filter)) return true;
    var terms = getRequestTypeFilterTerms(filter);
    var ticketType = toSafeString(ticket.requestType).toLowerCase();
    if (!ticketType || isGuid(ticketType)) return false;
    for (var i = 0; i < terms.length; i += 1) {
      var term = terms[i].toLowerCase();
      if (!term) continue;
      if (ticketType === term || ticketType.indexOf(term) >= 0 || term.indexOf(ticketType) >= 0) {
        return true;
      }
    }
    var title = toSafeString(ticket.requestTitle).toLowerCase();
    for (var j = 0; j < terms.length; j += 1) {
      var core = terms[j]
        .toLowerCase()
        .replace(/\s*request\s*$/i, "")
        .trim();
      if (core && title.indexOf(core) >= 0) return true;
    }
    return false;
  }

  function getTicketPermissionAppTitle(ticket) {
    if (!ticket) return "";

    var sourceTitle = pickField(ticket._sourceRow || {}, [
      "AppTitle",
      "appTitle",
      "RequestType",
      "WFName",
      "WfName",
    ]);
    if (isPermissionRestrictedAppTitle(sourceTitle)) return sourceTitle;

    var index;
    for (index = 0; index < DASHBOARD_APP_MATCHERS.length; index += 1) {
      var matcher = DASHBOARD_APP_MATCHERS[index];
      if (requestTypeMatches(ticket, matcher.label)) {
        return resolveAppTitleForRequestType(matcher.label);
      }
    }
    return "";
  }

  function isTicketVisibleByPermissions(ticket) {
    var appTitle = getTicketPermissionAppTitle(ticket);
    if (!appTitle) return true;

    var configs = Array.isArray(state.workflowConfigs) ? state.workflowConfigs : [];
    var index;
    for (index = 0; index < configs.length; index += 1) {
      if (toSafeString(configs[index].appTitle) === appTitle) return true;
    }
    return false;
  }

  function statusMatches(ticket, statusName, statusRecordId) {
    var name = toSafeString(statusName).toLowerCase();
    var recordId = toSafeString(statusRecordId).toLowerCase();
    if (!name && !recordId) return true;
    var status = toSafeString(ticket.status).toLowerCase();
    var statusRaw = toSafeString(ticket.statusRaw).toLowerCase();
    if (name && (status === name || statusRaw.indexOf(name) >= 0)) return true;
    if (recordId && statusRaw.indexOf(recordId) >= 0) return true;
    return false;
  }

  function applyClientFilters(rows) {
    var list = Array.isArray(rows) ? rows.slice() : [];
    var filters = state.filters;

    list = list.filter(function (ticket) {
      return isTicketVisibleByPermissions(ticket);
    });

    if (filters.statusName || filters.statusRecordId) {
      list = list.filter(function (ticket) {
        return statusMatches(ticket, filters.statusName, filters.statusRecordId);
      });
    }

    if (filters.requestType) {
      list = list.filter(function (ticket) {
        return requestTypeMatches(ticket, filters.requestType);
      });
    }

    if (filters.searchQuery) {
      var q = filters.searchQuery.toLowerCase();
      list = list.filter(function (ticket) {
        return ticket._searchText.indexOf(q) >= 0;
      });
    }

    return list;
  }

  async function reloadTickets() {
    var token = (myServicesFetchToken += 1);
    setTableMessage("Loading tickets");
    try {
      var rows = await fetchMyServices({
        statusName: state.filters.statusName,
        statusRecordId: state.filters.statusRecordId,
        requestType: state.filters.requestType,
        searchQuery: state.filters.searchQuery,
      });
      if (token !== myServicesFetchToken) return;
      state.allTickets = rows;
      state.filteredTickets = applyClientFilters(rows);
      renderTicketsTable();
    } catch (error) {
      if (token !== myServicesFetchToken) return;
      var msg = error && error.message ? error.message : "Unable to load tickets.";
      state.allTickets = [];
      state.filteredTickets = [];
      setTableMessage(msg);
      updateTableMeta();
    }
  }

  var REQUEST_TITLE_COLUMN_WIDTH = 280;
  var PRIORITY_COLUMN_WIDTH = 112;
  var STATUS_COLUMN_WIDTH = 130;

  function formatPriorityLabel(value) {
    var text = toSafeString(value);
    if (!text) return "";
    var key = text.toLowerCase();
    if (key.indexOf("high") >= 0) return "High";
    if (key.indexOf("medium") >= 0) return "Medium";
    if (key.indexOf("low") >= 0) return "Low";
    if (key.indexOf("critical") >= 0) return "Critical";
    if (text.length <= 16) return text;
    return text.slice(0, 14) + "\u2026";
  }

  // Reuses the shared .badge / .badge--* variants (see global.css) instead of
  // a page-specific palette - same semantic colors Team Dashboard's
  // BADGE_CLASS_MAP already maps ticket priority/status onto.
  function badgeClassForPriority(value) {
    var key = toSafeString(value).toLowerCase();
    if (key === "high" || key.indexOf("high") >= 0) return "badge--send-for-disposal";
    if (key === "medium" || key.indexOf("medium") >= 0) return "badge--in-repair";
    if (key === "low" || key.indexOf("low") >= 0) return "badge--in-store";
    return "";
  }

  function badgeClassForStatus(value) {
    var key = toSafeString(value).toLowerCase().replace(/\s+/g, "-");
    if (key === "open" || key.indexOf("open") === 0) return "badge--allocated";
    if (key.indexOf("progress") >= 0 || key.indexOf("pending") >= 0)
      return "badge--in-repair";
    if (key.indexOf("resolved") >= 0 || key.indexOf("closed") >= 0 || key.indexOf("complete") >= 0)
      return "badge--in-store";
    if (key.indexOf("cancel") >= 0 || key.indexOf("reject") >= 0)
      return "badge--send-for-disposal";
    return "badge--other";
  }

  function renderTableCellText(value) {
    return escapeHtml(toSafeString(value));
  }

  function renderBadge(value, kind) {
    var text =
      kind === "priority" ? formatPriorityLabel(value) : toSafeString(value);
    if (!text) return "";
    var cls =
      kind === "priority"
        ? badgeClassForPriority(text)
        : badgeClassForStatus(text);
    return (
      '<span class="badge ' +
      cls +
      '">' +
      escapeHtml(text) +
      "</span>"
    );
  }

  function getTicketLinkMeta(ticket) {
    if (!ticket) {
      return { oid: "", rid: "", incid: "", url: "" };
    }

    var linkIds = ticket.linkIds || resolveTicketLinkIds(ticket._sourceRow);
    var oid =
      linkIds.objectId || ticket.objectId || resolveWorkflowObjectId(ticket);
    var rid = linkIds.recordId || ticket.recordId;
    var incid = linkIds.instanceId || ticket.instanceId;
    var url = buildTicketDetailUrlParts(oid, rid, incid);

    return {
      oid: oid || "",
      rid: rid || "",
      incid: incid || "",
      url: url || "",
    };
  }

  function buildTicketDetailUrl(ticket) {
    return getTicketLinkMeta(ticket).url;
  }

  function openTicketDetailUrl(url) {
    var target = toSafeString(url);
    if (!target) return;
    window.location.assign(target);
  }

  function resolveTicketDetailUrlFromNode(node) {
    if (!node) return "";

    var stored = toSafeString(node.getAttribute("data-detail-url"));
    if (stored) return stored;

    var oid = node.getAttribute("data-oid") || "";
    var rid = node.getAttribute("data-rid") || "";
    var incid = node.getAttribute("data-incid") || "";
    return buildTicketDetailUrlParts(oid, rid, incid);
  }

  function createTicketDetailLink(label, meta) {
    var link = document.createElement("a");
    link.className = "reason-link";
    link.textContent = label;
    link.setAttribute("data-servdash-detail", "1");
    link.setAttribute("data-oid", meta.oid);
    link.setAttribute("data-rid", meta.rid);
    link.setAttribute("data-incid", meta.incid);

    if (meta.url) {
      link.href = meta.url;
      link.setAttribute("data-detail-url", meta.url);
      return link;
    }

    link.href = "#";
    if (!meta.rid) {
      link.setAttribute("aria-disabled", "true");
    }

    return link;
  }

  function applyTicketDetailLinks(tbody) {
    if (!tbody) return;

    var tickets = state.filteredTickets;
    var rows = tbody.querySelectorAll("tr");

    rows.forEach(function (row, index) {
      if (row.querySelector(".servdash-table-empty")) return;

      var ticket = tickets[index];
      if (!ticket) return;

      var meta = getTicketLinkMeta(ticket);
      row.setAttribute("data-oid", meta.oid);
      row.setAttribute("data-rid", meta.rid);
      row.setAttribute("data-incid", meta.incid);
      if (meta.url) row.setAttribute("data-detail-url", meta.url);
      else row.removeAttribute("data-detail-url");

      row.classList.toggle("servdash-ticket-row--clickable", Boolean(meta.url));

      [0, 1].forEach(function (colIndex) {
        var cell = row.children[colIndex];
        if (!cell) return;

        var label = toSafeString(cell.textContent);
        if (!label) return;

        cell.textContent = "";
        cell.appendChild(createTicketDetailLink(label, meta));
      });
    });
  }

  function bindTicketTableLinks() {
    var wrap = document.querySelector(".servdash-table-wrap");
    if (!wrap || wrap.__servdashTicketLinksBound) return;
    wrap.__servdashTicketLinksBound = true;

    wrap.addEventListener("click", function (event) {
      var link = event.target.closest("a.reason-link[data-servdash-detail]");
      if (link) {
        var href = toSafeString(link.getAttribute("href"));
        if (href && href !== "#") return;

        var linkUrl = resolveTicketDetailUrlFromNode(link);
        if (!linkUrl) return;

        event.preventDefault();
        openTicketDetailUrl(linkUrl);
        return;
      }

      var row = event.target.closest("#servdashTicketsBody tr");
      if (!row || row.querySelector(".servdash-table-empty")) return;

      var rowUrl = resolveTicketDetailUrlFromNode(row);
      if (!rowUrl) return;

      event.preventDefault();
      openTicketDetailUrl(rowUrl);
    });
  }

  function setPageBusy(isBusy) {
    var root = document.getElementById("servdashPageRoot");
    if (root) root.setAttribute("aria-busy", String(Boolean(isBusy)));
  }

  function setTableMessage(message) {
    var tbody = document.getElementById("servdashTicketsBody");
    if (!tbody) return;
    tbody.innerHTML =
      '<tr><td colspan="10" class="servdash-table-empty">' +
      escapeHtml(message) +
      "</td></tr>";
    ensureGridTable();
  }

  function updateTableMeta() {
    var meta = document.getElementById("servdashTableMeta");
    if (!meta) return;
    var count = state.filteredTickets.length;
    meta.textContent = count
      ? count + " ticket" + (count === 1 ? "" : "s") + " for your account"
      : "No tickets match the current filters";
  }

  // Column layout handed to GridTable, which owns all column sizing (see
  // library.js "COLUMN WIDTH ENGINE"). Only the columns with a deliberate
  // width are listed; GridTable measures the rest. Sparse on purpose - a gap
  // means "no opinion", not zero. This page no longer writes to <colgroup>
  // itself, so only one system ever sizes the grid.
  function getDashboardColumnWidths() {
    var widths = [];
    widths[1] = REQUEST_TITLE_COLUMN_WIDTH;
    widths[4] = PRIORITY_COLUMN_WIDTH;
    widths[8] = STATUS_COLUMN_WIDTH;
    return widths;
  }

  function fixTableSortIcons(table) {
    if (!table) return;
    table.querySelectorAll("thead th").forEach(function (header) {
      header.querySelectorAll(".gt-sort-icon, .th-sort-icon").forEach(function (icon) {
        icon.textContent = "";
        icon.setAttribute("aria-hidden", "true");
      });
    });
  }

  function destroyGridTableInstance() {
    if (gridTableInstance && typeof gridTableInstance.destroy === "function") {
      gridTableInstance.destroy();
    }
    gridTableInstance = null;
  }

  function ensureGridTable() {
    var table = document.getElementById("servdashTicketsTable");
    if (!table || !window.GridTable) return;

    // Recreate against the current rows every time rather than only
    // refreshing the instance created on first load -- see fix note above.
    destroyGridTableInstance();

    gridTableInstance = window.GridTable.create(table, {
      sortable: true,
      resizable: true,
      resizeStorageKey: "servdash-my-services",
      minWidth: 90,
      maxWidth: 480,
      columnWidths: getDashboardColumnWidths(),
      headerSelector: "thead th",
      bodySelector: "tbody",
      sortableHeaderClass: "gt-sortable",
      sortIconClass: "gt-sort-icon",
    });
    fixTableSortIcons(table);
  }

  /**
   * Opening <td> for a date column. Carries the UTC epoch as data-sort-value so
   * a grid that honours it sorts chronologically rather than by display text.
   * Harmless if the grid ignores the attribute.
   */
  function dateCellOpenTag(sortValue) {
    var sortAttr = sortValue == null ? "" : ' data-sort-value="' + sortValue + '"';
    return '<td class="servdash-col-date"' + sortAttr + ">";
  }

  // "DD/MM/YYYY hh:mm:ss AM/PM" (or the 24-hour form) split into the date and
  // the time, the time keeping the separating space.
  var DATE_CELL_SPLIT_PATTERN = /^(\d{2}\/\d{2}\/\d{4})( .+)$/;

  /**
   * Date cells print the date above the time - the two-line shape the narrow
   * Due Date column already produced by wrapping at its space. Emitting the two
   * halves as blocks makes that break explicit, so Created Date matches Due Date
   * at any column width instead of depending on the room it happens to have.
   *
   * The separating space stays inside the time span, so the cell's textContent is
   * unchanged - GridTable sorts on cell text (see library.js getCellText).
   */
  function renderDateCellText(value) {
    var text = toSafeString(value);
    var parts = DATE_CELL_SPLIT_PATTERN.exec(text);
    if (!parts) return escapeHtml(text);
    return (
      '<span class="servdash-date-cell__date">' + escapeHtml(parts[1]) + "</span>" +
      '<span class="servdash-date-cell__time">' + escapeHtml(parts[2]) + "</span>"
    );
  }

  function renderTicketsTable() {
    var tbody = document.getElementById("servdashTicketsBody");
    if (!tbody) return;

    var tickets = state.filteredTickets;
    if (!tickets.length) {
      setTableMessage("No tickets found.");
      updateTableMeta();
      return;
    }

    tbody.innerHTML = tickets
      .map(function (ticket) {
        return (
          "<tr>" +
          "<td>" +
          renderTableCellText(ticket.ticketId) +
          "</td>" +
          '<td class="servdash-col-request-title">' +
          renderTableCellText(ticket.requestTitle) +
          "</td>" +
          "<td>" +
          renderTableCellText(ticket.ticketType) +
          "</td>" +
          "<td>" +
          renderTableCellText(ticket.requester) +
          "</td>" +
          '<td class="servdash-col-priority">' +
          renderBadge(ticket.priority, "priority") +
          "</td>" +
          dateCellOpenTag(ticket.dueDateSort) +
          renderDateCellText(ticket.dueDate) +
          "</td>" +
          "<td>" +
          renderTableCellText(ticket.assignedTo) +
          "</td>" +
          "<td>" +
          renderTableCellText(ticket.assignedTeam) +
          "</td>" +
          '<td class="servdash-col-status">' +
          renderBadge(ticket.status, "status") +
          "</td>" +
          dateCellOpenTag(ticket.createdDateSort) +
          renderDateCellText(ticket.createdDate) +
          "</td>" +
          "</tr>"
        );
      })
      .join("");

    applyTicketDetailLinks(tbody);
    updateTableMeta();
    ensureGridTable();
  }

  // The "New" autocomplete registers its own close routine here (see
  // bindNewAppPicker) so that only one toolbar dropdown is ever open at a
  // time: opening a custom select closes the autocomplete, and vice versa.
  var closeServdashNewAppList = null;

  function closeServdashSelectMenus() {
    var openWraps = document.querySelectorAll(".servdash-custom-select.is-open");
    openWraps.forEach(function (wrap) {
      wrap.classList.remove("is-open");
      var menu = wrap.querySelector(".servdash-select-menu");
      var trigger = wrap.querySelector(".servdash-select-trigger");
      if (menu) menu.hidden = true;
      if (trigger) trigger.setAttribute("aria-expanded", "false");
    });
  }

  function openServdashSelectMenu(wrap) {
    closeServdashSelectMenus();
    if (typeof closeServdashNewAppList === "function") closeServdashNewAppList();
    wrap.classList.add("is-open");
    var menu = wrap.querySelector(".servdash-select-menu");
    var trigger = wrap.querySelector(".servdash-select-trigger");
    if (menu) menu.hidden = false;
    if (trigger) trigger.setAttribute("aria-expanded", "true");
  }

  function syncServdashCustomSelect(select) {
    var wrap = select && select.closest(".servdash-custom-select");
    if (!wrap) return;

    var label = wrap.querySelector(".servdash-select-trigger__label");
    var menu = wrap.querySelector(".servdash-select-menu");
    if (!label || !menu) return;

    var value = toSafeString(select.value);
    var placeholder = toSafeString(select.getAttribute("data-placeholder"));
    var selected = select.options[select.selectedIndex];
    var selectedText = selected ? selected.text : "";
    if (!value && placeholder) {
      label.textContent = placeholder;
      label.removeAttribute("title");
    } else {
      label.textContent = selectedText;
      // Full value stays available on hover/focus even though the label itself
      // is truncated with an ellipsis when it doesn't fit.
      if (selectedText) label.title = selectedText;
      else label.removeAttribute("title");
    }

    var hasValue = Boolean(value);
    wrap.classList.toggle("has-value", hasValue);
    var clearBtn = wrap.querySelector(".servdash-select-clear");
    if (clearBtn) clearBtn.hidden = !hasValue;

    var optionButtons = menu.querySelectorAll(".servdash-select-option");
    optionButtons.forEach(function (btn) {
      var isSelected = toSafeString(btn.getAttribute("data-value")) === value;
      btn.classList.toggle("is-selected", isSelected);
      btn.setAttribute("aria-selected", isSelected ? "true" : "false");
    });
  }

  function buildServdashSelectMenu(select, menu) {
    menu.innerHTML = "";
    for (var i = 0; i < select.options.length; i += 1) {
      (function (opt) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "servdash-select-option";
        btn.setAttribute("role", "option");
        btn.setAttribute("data-value", opt.value);
        btn.textContent = opt.text;
        btn.addEventListener("click", function (event) {
          event.stopPropagation();
          select.value = opt.value;
          closeServdashSelectMenus();
          select.dispatchEvent(new Event("change", { bubbles: true }));
          syncServdashCustomSelect(select);
        });
        menu.appendChild(btn);
      })(select.options[i]);
    }
  }

  function bindServdashSelectOutsideClose() {
    if (document.__servdashSelectOutsideBound) return;
    document.__servdashSelectOutsideBound = true;
    document.addEventListener("click", closeServdashSelectMenus);
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeServdashSelectMenus();
    });
  }

  function enhanceServdashSelect(select) {
    if (!select) return;

    if (select.__servdashCustomEnhanced) {
      syncServdashCustomSelect(select);
      return;
    }

    var wrap = select.closest(".servdash-select-wrap");
    if (!wrap) return;

    wrap.classList.add("servdash-custom-select");
    select.classList.add("servdash-select--native");

    var oldChevron = wrap.querySelector(":scope > .servdash-select__chevron");
    if (oldChevron) oldChevron.remove();

    // A real <button> (the clear control) can't nest inside another <button>,
    // so the trigger is a div exposed to assistive tech via role="button".
    var trigger = document.createElement("div");
    trigger.className = "servdash-select-trigger";
    trigger.setAttribute("role", "button");
    trigger.setAttribute("tabindex", "0");
    trigger.setAttribute("aria-haspopup", "listbox");
    trigger.setAttribute("aria-expanded", "false");

    var label = document.createElement("span");
    label.className = "servdash-select-trigger__label";

    // Icon glyph (fa-angle-down) instead of a hand-drawn CSS chevron, so it
    // matches the "New" autocomplete's arrow exactly (shared .qaf-arrow-icon
    // class in global.css controls the size/color).
    var chevron = document.createElement("i");
    chevron.className = "fa fa-angle-down servdash-select__chevron qaf-arrow-icon";
    chevron.setAttribute("aria-hidden", "true");

    var clearBtn = document.createElement("button");
    clearBtn.type = "button";
    clearBtn.className = "servdash-select-clear";
    clearBtn.setAttribute("aria-label", "Clear selection");
    clearBtn.innerHTML = "&times;";
    clearBtn.hidden = true;

    trigger.appendChild(label);
    trigger.appendChild(chevron);
    trigger.appendChild(clearBtn);

    var menu = document.createElement("div");
    menu.className = "servdash-select-menu";
    menu.setAttribute("role", "listbox");
    menu.hidden = true;

    wrap.appendChild(trigger);
    wrap.appendChild(menu);

    buildServdashSelectMenu(select, menu);
    syncServdashCustomSelect(select);

    trigger.addEventListener("click", function (event) {
      event.stopPropagation();
      if (wrap.classList.contains("is-open")) closeServdashSelectMenus();
      else openServdashSelectMenu(wrap);
    });

    trigger.addEventListener("keydown", function (event) {
      if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") {
        event.preventDefault();
        event.stopPropagation();
        if (wrap.classList.contains("is-open")) closeServdashSelectMenus();
        else openServdashSelectMenu(wrap);
      } else if (event.key === "Escape") {
        closeServdashSelectMenus();
      }
    });

    clearBtn.addEventListener("click", function (event) {
      event.stopPropagation();
      select.value = "";
      closeServdashSelectMenus();
      select.dispatchEvent(new Event("change", { bubbles: true }));
      syncServdashCustomSelect(select);
    });

    bindServdashSelectOutsideClose();
    select.__servdashCustomEnhanced = true;
  }

  function refreshServdashCustomSelect(select) {
    if (!select) return;
    if (!select.__servdashCustomEnhanced) {
      enhanceServdashSelect(select);
      return;
    }
    var wrap = select.closest(".servdash-custom-select");
    var menu = wrap && wrap.querySelector(".servdash-select-menu");
    if (menu) buildServdashSelectMenu(select, menu);
    syncServdashCustomSelect(select);
  }

  function initServdashToolbarSelects() {
    enhanceServdashSelect(document.getElementById("servdashStatusSelect"));
    enhanceServdashSelect(document.getElementById("servdashTypeSelect"));
  }

  function renderRequestTypeSelect() {
    var select = document.getElementById("servdashTypeSelect");
    if (!select) return;

    var html = '<option value="">All Types</option>';
    state.typeOptions.forEach(function (name) {
      html +=
        '<option value="' + escapeHtml(name) + '">' + escapeHtml(name) + "</option>";
    });

    var previousValue = toSafeString(select.value);
    select.innerHTML = html;
    if (previousValue) {
      var matched = false;
      for (var i = 0; i < select.options.length; i += 1) {
        if (select.options[i].value === previousValue) {
          select.value = previousValue;
          matched = true;
          break;
        }
      }
      if (!matched) select.value = "";
    } else {
      select.value = "";
    }

    refreshServdashCustomSelect(select);
  }

  function renderStatusSelect() {
    var select = document.getElementById("servdashStatusSelect");
    if (!select) return;

    var options = state.statusOptions.slice().sort(function (a, b) {
      return toSafeString(a.statusName).localeCompare(toSafeString(b.statusName), undefined, {
        sensitivity: "base",
      });
    });

    var html = '<option value="">All Status</option>';
    options.forEach(function (opt) {
      var recordId = toSafeString(opt.recordId);
      var statusName = toSafeString(opt.statusName);
      if (!statusName) return;
      html +=
        '<option value="' +
        escapeHtml(recordId || statusName) +
        '">' +
        escapeHtml(statusName) +
        "</option>";
    });

    var previousValue = toSafeString(select.value);
    select.innerHTML = html;
    if (previousValue) {
      var matched = false;
      for (var i = 0; i < select.options.length; i += 1) {
        if (select.options[i].value === previousValue) {
          select.value = previousValue;
          matched = true;
          break;
        }
      }
      if (!matched) select.value = "";
    } else {
      select.value = "";
    }

    refreshServdashCustomSelect(select);
  }

  function bindStatusFilter() {
    var select = document.getElementById("servdashStatusSelect");
    if (!select || select.__servdashStatusBound) return;
    select.__servdashStatusBound = true;
    select.addEventListener("change", function () {
      var selected = select.options[select.selectedIndex];
      var value = toSafeString(select.value);
      state.filters.statusRecordId = value;
      state.filters.statusName = selected ? toSafeString(selected.text) : "";
      if (!value) {
        state.filters.statusName = "";
        state.filters.statusRecordId = "";
      }
      reloadTickets();
    });
  }

  var servdashSearchHandle = null;

  function updateSearchClearVisibility() {
    if (servdashSearchHandle) {
      servdashSearchHandle.syncClearButton();
      return;
    }
    var input = document.getElementById("servdashSearchInput");
    var clearBtn = document.getElementById("servdashSearchClear");
    if (!input || !clearBtn) return;
    if (input.value.length > 0) clearBtn.removeAttribute("hidden");
    else clearBtn.setAttribute("hidden", "");
  }

  function bindSearch() {
    var input = document.getElementById("servdashSearchInput");
    var clearBtn = document.getElementById("servdashSearchClear");
    if (!input || input.__servdashSearchBound) return;
    input.__servdashSearchBound = true;

    if (window.QafLibrary && typeof window.QafLibrary.bindSearchClear === "function") {
      servdashSearchHandle = window.QafLibrary.bindSearchClear(input, clearBtn, {
        onEnter: function (value) {
          state.filters.searchQuery = toSafeString(value);
          reloadTickets();
        },
        onClear: function () {
          state.filters.searchQuery = "";
          reloadTickets();
        }
      });
      return;
    }

    // Fallback if the shared library helper isn't available for any reason.
    input.addEventListener("keydown", function (event) {
      if (event.key !== "Enter") return;
      event.preventDefault();
      state.filters.searchQuery = toSafeString(input.value);
      reloadTickets();
    });

    input.addEventListener("input", function () {
      updateSearchClearVisibility();
    });

    if (clearBtn) {
      clearBtn.addEventListener("click", function () {
        input.value = "";
        updateSearchClearVisibility();
        state.filters.searchQuery = "";
        reloadTickets();
        input.focus();
      });
    }
  }

  function bindTypeFilter() {
    var select = document.getElementById("servdashTypeSelect");
    if (!select || select.__servdashTypeBound) return;
    select.__servdashTypeBound = true;
    select.addEventListener("change", function () {
      state.filters.requestType = toSafeString(select.value);
      reloadTickets();
    });
  }

  // "New" is a quick-create autocomplete, not a grid filter: it type-filters
  // the exact same workflow apps as the Service Catalog (same
  // permission/config rules, reused via window.QafServiceCatalog) and opens
  // the same OOTB add form.
  function renderNewAppOptions(list, query) {
    var q = toSafeString(query).toLowerCase();
    var sorted = state.newApps.slice().sort(function (a, b) {
      return toSafeString(a.appTitle).localeCompare(toSafeString(b.appTitle), undefined, {
        sensitivity: "base",
      });
    });
    var filtered = q
      ? sorted.filter(function (app) {
          return toSafeString(app.appTitle).toLowerCase().indexOf(q) >= 0;
        })
      : sorted;

    if (!filtered.length) {
      // "No services available." is only truthful once a load has actually
      // succeeded - while one is still in flight (or has just failed) the
      // empty list is a load state, not an empty result.
      var emptyMessage;
      if (state.newApps.length) emptyMessage = "No matching services";
      else if (state.newAppsLoaded) emptyMessage = "No services available.";
      else if (state.newAppsError) emptyMessage = "Unable to load services.";
      else emptyMessage = "Loading services…";

      list.innerHTML =
        '<li class="qaf-app-picker__empty">' + emptyMessage + "</li>";
      return;
    }
    list.innerHTML = filtered
      .map(function (app) {
        return (
          '<li class="qaf-app-picker__option" role="option" data-app-id="' +
          escapeHtml(app.id) +
          '">' +
          escapeHtml(app.appTitle) +
          "</li>"
        );
      })
      .join("");
  }

  function loadNewAppOptions() {
    if (state.newAppsLoaded) return Promise.resolve(state.newApps.slice());
    if (newAppOptionsPromise) return newAppOptionsPromise;

    var qafServiceCatalog = window.QafServiceCatalog;
    if (!qafServiceCatalog || typeof qafServiceCatalog.getAvailableApps !== "function") {
      // service.js hasn't published the API yet. Leave newAppsLoaded false so
      // the next open retries instead of caching an empty list for the whole
      // page session.
      state.newApps = [];
      state.newAppsError = true;
      return Promise.resolve([]);
    }

    state.newAppsError = false;

    newAppOptionsPromise = qafServiceCatalog
      .getAvailableApps()
      .then(function (apps) {
        state.newApps = Array.isArray(apps) ? apps : [];
        state.newAppsLoaded = true;
        state.newAppsError = false;
        newAppOptionsPromise = null;
        return state.newApps.slice();
      })
      .catch(function () {
        // A failed fetch (transient network/API error) must NOT be cached as
        // "loaded with zero services" - that is what left the picker stuck on
        // "No services available." until a page reload. newAppsLoaded stays
        // false, so reopening the picker refetches (WorkflowConfigList itself
        // also clears its cached promise on error).
        state.newApps = [];
        state.newAppsError = true;
        newAppOptionsPromise = null;
        return [];
      });

    return newAppOptionsPromise;
  }

  function bindNewAppPicker() {
    var root = document.getElementById("servdashNewAppPicker");
    var input = document.getElementById("servdashNewAppInput");
    var list = document.getElementById("servdashNewAppList");
    if (!root || !input || !list || root.__servdashNewBound) return;
    root.__servdashNewBound = true;

    var portal =
      window.QafLibrary &&
      window.QafLibrary.Dropdown &&
      typeof window.QafLibrary.Dropdown.createPortal === "function"
        ? window.QafLibrary.Dropdown.createPortal(root, input, list)
        : null;

    function closeList() {
      list.hidden = true;
      input.setAttribute("aria-expanded", "false");
      input.value = "";
      if (portal) portal.detach();
    }

    function openList() {
      // Status / All Types are closed here (and this list is closed from
      // openServdashSelectMenu) so two toolbar lists never overlap.
      closeServdashSelectMenus();
      list.hidden = false;
      input.setAttribute("aria-expanded", "true");
      if (portal) portal.attach();
    }

    function showOptionsForQuery() {
      renderNewAppOptions(list, input.value);
      if (!state.newAppsLoaded) {
        loadNewAppOptions().then(function () {
          if (!list.hidden) renderNewAppOptions(list, input.value);
        });
      }
    }

    // Let the custom selects close this list when one of them opens. Guarded
    // on `hidden` so an already-closed list is never re-cleared.
    closeServdashNewAppList = function () {
      if (!list.hidden) closeList();
    };

    // The OOTB form takes focus when it opens, and the platform hands focus
    // back to this input when it closes - which fired the handler below and
    // re-opened the "New" list every time a form was saved. The first focus
    // after a form is launched from here is therefore ignored. A real pointer
    // press clears the guard first, so clicking straight back in still opens.
    var suppressNextFocusOpen = false;

    input.addEventListener("mousedown", function () {
      suppressNextFocusOpen = false;
    });

    input.addEventListener("focus", function () {
      if (suppressNextFocusOpen) {
        suppressNextFocusOpen = false;
        return;
      }
      openList();
      showOptionsForQuery();
    });

    input.addEventListener("input", function () {
      if (list.hidden) openList();
      renderNewAppOptions(list, input.value);
    });

    input.addEventListener("keydown", function (event) {
      if (event.key === "Escape") {
        event.preventDefault();
        closeList();
        input.blur();
      }
    });

    list.addEventListener("mousedown", function (event) {
      var option = event.target.closest(".qaf-app-picker__option[data-app-id]");
      if (!option) return;
      event.preventDefault();
      var appId = option.getAttribute("data-app-id");
      var app = state.newApps.find(function (candidate) {
        return candidate.id === appId;
      });
      closeList();
      if (!app || !window.QafServiceCatalog || typeof window.QafServiceCatalog.openAppForm !== "function") {
        return;
      }
      suppressNextFocusOpen = true;
      input.blur();
      window.QafServiceCatalog.openAppForm(app, function () {
        reloadTickets();
      });
    });

    if (
      window.QafLibrary &&
      window.QafLibrary.Dropdown &&
      typeof window.QafLibrary.Dropdown.registerOutsideClose === "function"
    ) {
      window.QafLibrary.Dropdown.registerOutsideClose(function (target) {
        return root.contains(target) || list.contains(target);
      }, closeList);
    } else {
      document.addEventListener("click", function (event) {
        if (!root.contains(event.target) && !list.contains(event.target)) {
          closeList();
        }
      });
    }
  }

  function initNavDock() {
    if (!document.getElementById("qafNavdockList")) return;
    var api = window.QafNavDock;
    if (!api || typeof api.init !== "function") return;

    if (!getNewLPFromStorage()) {
      paintNavDockPlaceholder();
      scheduleNavDockInitWhenReady();
      return;
    }

    api.init({
      toggleElementId: "qafNavToggle",
      listElementId: "qafNavdockList",
    });
  }

  async function loadPageData() {
    setPageBusy(true);
    setTableMessage("Loading tickets");

    // Toolbar component data (Status/Type/New options) loads in the
    // background and never blocks or delays the ticket grid below - each
    // populates its own dropdown independently, whenever it happens to
    // resolve.
    var componentLoads = Promise.allSettled([
      fetchStatusOptionsOnce().then(function (options) {
        state.statusOptions = options;
        renderStatusSelect();
      }),
      loadRequestTypeOptions().then(function (options) {
        state.typeOptions = options;
        renderRequestTypeSelect();
      }),
      loadNewAppOptions(),
    ]);

    // Main data: the ticket grid itself. WorkflowConfigList is included
    // here (not with the component loads above) because the grid's own
    // permission filtering and detail-link resolution depend on it - the
    // table is only ever rendered once, with permissions already applied,
    // instead of rendering unfiltered rows first and correcting them later.
    try {
      var results = await Promise.all([fetchWorkflowConfigListOnce(), fetchMyServices({})]);

      state.workflowConfigs = results[0];
      state.allTickets = results[1];
      state.filteredTickets = applyClientFilters(state.allTickets);

      renderTicketsTable();
    } catch (error) {
      var msg = error && error.message ? error.message : "Unable to load dashboard.";
      setTableMessage(msg);
      updateTableMeta();
    } finally {
      setPageBusy(false);
    }

    await componentLoads;
  }

  function onDocumentReady(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  hidePageContent();
  paintNavDockPlaceholder();

  onDocumentReady(function () {
    paintNavDockPlaceholder();
    if (!enforcePageAccess()) return;
    showPageContent();
    initNavDock();
    bindNewAppPicker();
    bindStatusFilter();
    bindSearch();
    bindTypeFilter();
    renderRequestTypeSelect();
    initServdashToolbarSelects();
    bindTicketTableLinks();
    updateSearchClearVisibility();
    ensureGridTable();
    loadPageData();
  });
})();